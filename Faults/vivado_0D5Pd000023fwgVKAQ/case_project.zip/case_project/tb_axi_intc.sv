`timescale 1ns/1ps
// 独立事务级参考模型：只由测试输入、已完成的写事务和硬件输入边沿更新。
// 不访问 DUT 内部，不把 DUT 的读回值用作期望，也不 force 任何 IP 信号。
module tb_axi_intc;
  localparam integer HW_COUNT = 8;
  localparam integer SW_COUNT = 0;
  localparam bit IRQ_ACTIVE = 0;
  localparam logic [31:0] HW_MASK = 32'h000000FF;
  localparam logic [31:0] ALL_MASK = 32'h000000FF;
  localparam logic [31:0] SW_MASK = ALL_MASK & ~HW_MASK;
  localparam logic [8:0] ISR=9'h000, IPR=9'h004, IER=9'h008, IAR=9'h00C;
  localparam logic [8:0] SIE=9'h010, CIE=9'h014, IVR=9'h018, MER=9'h01C, ILR=9'h024;

  reg clk=0, resetn=0;
  always #5 clk=~clk; // 100 MHz，两类输入都以此为时序基准。
  reg [HW_COUNT-1:0] intr=0;
  wire irq;
  reg [8:0] s_axi_awaddr=0,s_axi_araddr=0;
  reg [31:0] s_axi_wdata=0;
  reg [3:0] s_axi_wstrb=4'hF;
  wire [31:0] s_axi_rdata;
  reg s_axi_awvalid=0,s_axi_wvalid=0,s_axi_bready=0;
  reg s_axi_arvalid=0,s_axi_rready=0;
  wire s_axi_awready,s_axi_wready,s_axi_bvalid,s_axi_arready,s_axi_rvalid;
  wire [1:0] s_axi_bresp,s_axi_rresp;

  axi_intc_0 dut(
    .s_axi_aclk(clk),.s_axi_aresetn(resetn),.intr(intr),.irq(irq),
    .s_axi_awaddr(s_axi_awaddr),.s_axi_awvalid(s_axi_awvalid),.s_axi_awready(s_axi_awready),
    .s_axi_wdata(s_axi_wdata),.s_axi_wstrb(s_axi_wstrb),.s_axi_wvalid(s_axi_wvalid),.s_axi_wready(s_axi_wready),
    .s_axi_bresp(s_axi_bresp),.s_axi_bvalid(s_axi_bvalid),.s_axi_bready(s_axi_bready),
    .s_axi_araddr(s_axi_araddr),.s_axi_arvalid(s_axi_arvalid),.s_axi_arready(s_axi_arready),
    .s_axi_rdata(s_axi_rdata),.s_axi_rresp(s_axi_rresp),.s_axi_rvalid(s_axi_rvalid),.s_axi_rready(s_axi_rready));

  // PG099 MER：ME=0 应关闭 IRQ，但不清除 ISR 中的待处理中断。
  // 参考 IRQ 由 ME 与已使能的待处理中断共同决定，再按配置转换为有效电平。
  // 模型内部状态不加入默认波形，仅显示读回预期和 IRQ 预期。
  logic [31:0] model_isr=0,model_ier=0,model_ilr=32'hFFFFFFFF;
  bit model_me=0,model_hie=0;
  reg [HW_COUNT-1:0] previous_intr=0;
  logic [31:0] expected_rdata=0;
  wire expected_irq=(model_me && |(model_isr & model_ier)) ? IRQ_ACTIVE : !IRQ_ACTIVE;
  integer mismatches=0,controls=0;

  // 本例所有硬件输入均为上升沿触发；HIE=1 时锁存输入的 0->1。
  // 此处是功能状态预测，不复制官方同步流水线；比较前等待 32 拍，远大于同步级数。
  // 写模型在下降沿更新，硬件采样在上升沿，且本例不同时注入硬件边沿和软件写入。
  always @(posedge clk) begin
    if(!resetn) begin
      model_isr=0;model_ier=0;model_ilr=32'hFFFFFFFF;model_me=0;model_hie=0;
      previous_intr=0;
    end else begin
      if(model_hie) model_isr = model_isr | ((intr & ~previous_intr) & HW_MASK);
      previous_intr=intr;
    end
  end

  // PG099 ISR：允许软件写入的位上，写 1 置位，写 0 无影响。
  // HIE=0：硬件对应位也允许软件触发；HIE=1：仅专用软件中断位可软件触发。
  task automatic model_write(input logic[8:0] address,input logic[31:0] value);
    logic [31:0] writable;
    writable = model_hie ? SW_MASK : ALL_MASK;
    case(address)
      ISR: model_isr = model_isr | (value & writable);
      IER: model_ier = value & ALL_MASK;
      IAR: model_isr = model_isr & ~(value & ALL_MASK);
      SIE: model_ier = model_ier | (value & ALL_MASK);
      CIE: model_ier = model_ier & ~(value & ALL_MASK);
      MER: begin model_me=value[0];model_hie=model_hie | value[1];end
      ILR: model_ilr=value; // 本例不改变 ILR；保持复位时的无屏蔽状态。
      default: $fatal(1,"MODEL unsupported write address");
    endcase
  endtask

  // IVR 是编号而不是位掩码：从最低编号起查找已使能且待处理的第一位。
  function automatic logic[31:0] model_read(input logic[8:0] address);
    logic [31:0] pending,result;
    pending=model_isr & model_ier;
    case(address)
      ISR: result=model_isr;
      IPR: result=pending;
      IER: result=model_ier;
      MER: result={30'd0,model_hie,model_me};
      ILR: result=model_ilr;
      IVR: begin
        result=32'hFFFFFFFF;
        for(int bit_index=0;bit_index<HW_COUNT+SW_COUNT;bit_index++) begin
          if(pending[bit_index]) begin result=bit_index;break;end
        end
      end
      default: result=32'hXXXXXXXX;
    endcase
    return result;
  endfunction

  task automatic settle(input integer clocks=32);
    repeat(clocks) @(negedge clk);
  endtask

  // AXI-Lite 写入：独立确认 AW/W，完整等待 B 响应，最后才提交参考模型状态。
  // DUT 输出仅用于握手/响应检查，不参与期望数据计算。
  task automatic write_reg(input logic[8:0] address,input logic[31:0] value);
    bit address_done,data_done;
    address_done=0;data_done=0;
    @(negedge clk);
    s_axi_awaddr=address;s_axi_wdata=value;s_axi_awvalid=1;s_axi_wvalid=1;
    for(int timeout=0;timeout<512;timeout++) begin
      @(posedge clk);
      if(s_axi_awvalid && s_axi_awready) address_done=1;
      if(s_axi_wvalid && s_axi_wready) data_done=1;
      @(negedge clk);
      if(address_done) s_axi_awvalid=0;
      if(data_done) s_axi_wvalid=0;
      if(address_done && data_done) break;
    end
    if(!(address_done && data_done)) $fatal(1,"AXI write request timeout");
    settle(2);s_axi_bready=1;
    for(int timeout=0;timeout<512;timeout++) begin @(posedge clk);if(s_axi_bvalid) break;end
    if(s_axi_bvalid!==1 || s_axi_bresp!==0) $fatal(1,"AXI write response error");
    @(negedge clk);s_axi_bready=0;model_write(address,value);
    $display("WRITE addr=%03h data=%08h time=%0t",address,value,$time);
    settle();
  endtask

  // 在 RVALID/RREADY 同时为 1 的采样沿比较数据，绝不比较无效周期 RDATA。
  // control=1 表示复位/初始状态/清除等正向对照；对照异常立即停止，避免误判。
  task automatic read_check(input logic[8:0] address,input string label_text,input bit control);
    logic [31:0] actual;
    @(negedge clk);expected_rdata=model_read(address);s_axi_araddr=address;s_axi_arvalid=1;
    for(int timeout=0;timeout<512;timeout++) begin @(posedge clk);if(s_axi_arready) break;end
    if(s_axi_arready!==1) $fatal(1,"AXI read request timeout");
    @(negedge clk);s_axi_arvalid=0;settle(4);s_axi_rready=1;
    for(int timeout=0;timeout<512;timeout++) begin @(posedge clk);if(s_axi_rvalid) break;end
    if(s_axi_rvalid!==1 || s_axi_rresp!==0 || $isunknown(s_axi_rdata)) $fatal(1,"AXI read response error");
    actual=s_axi_rdata;
    $display("READ %s addr=%03h expected=%08h actual=%08h control=%0d",label_text,address,expected_rdata,actual,control);
    if(actual!==expected_rdata) begin
      if(control) $fatal(1,"CONTROL_FAILED %s",label_text);
      mismatches++;$display("MISMATCH %s",label_text);
    end else if(control) controls++;
    @(negedge clk);s_axi_rready=0;settle();
  endtask

  task automatic check_irq(input string label_text,input bit control);
    $display("IRQ %s expected=%b actual=%b control=%0d",label_text,expected_irq,irq,control);
    if(irq!==expected_irq) begin
      if(control) $fatal(1,"CONTROL_FAILED %s",label_text);
      mismatches++;$display("MISMATCH %s",label_text);
    end else if(control) controls++;
  endtask

  initial begin
    settle(32);resetn=1;settle();
    read_check(ISR,"reset_isr",1);check_irq("reset_irq",1);
    write_reg(SIE,32'h00000080);write_reg(MER,32'h00000003);
    read_check(IER,"enabled_sources",1);read_check(MER,"master_enabled",1);
    check_irq("enabled_without_pending",1);
    // 硬件输入保持 20 拍，恢复低电平后等待同步链稳定，再读取锁存状态。
    @(negedge clk);intr=32'h00000080;settle(20);intr=0;settle(32);
    read_check(ISR,"hardware_pending_0",1);
    read_check(ISR,"baseline_isr",1);check_irq("baseline_irq",1);
    read_check(IPR,"baseline_ipr",1);
    // 仅关闭主使能 ME，保留 HIE=1；不在观测期间修改 IER 或确认中断。
    write_reg(MER,32'h00000002);
    settle(320); // 写响应后额外等待，避免把正常输出延迟当成故障。
    read_check(MER,"master_disabled",1);
    read_check(ISR,"pending_after_disable",1);
    check_irq("irq_after_disable",0);
    read_check(IPR,"pending_ipr_after_disable",1);
    // 对照：屏蔽单路使能后，确认 IRQ 恢复为无效电平，ISR 仍保留。
    write_reg(IER,32'h00000000);check_irq("ier_masked_irq",1);
    read_check(ISR,"pending_after_ier_mask",1);
    // 结束对照：正式确认全部中断，状态及 IRQ 应恢复。
    write_reg(IAR,32'h00000080);
    read_check(ISR,"acknowledged_isr",1);check_irq("acknowledged_irq",1);
    settle(40);
    if(mismatches) $display("TEST_RESULT FAIL mismatches=%0d controls=%0d",mismatches,controls);
    else $display("TEST_RESULT PASS mismatches=0 controls=%0d",controls);
    $display("TEST_COMPLETE");$finish;
  end
  initial begin #1000000;$fatal(1,"TEST_TIMEOUT");end
endmodule

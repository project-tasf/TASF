# 自动记录 IP 接口与参考结果，运行单次测试；不改变 DUT 或激励。
create_wave_config axi_intc_case
add_wave_divider {Clock and hardware input}
foreach name {clk resetn processor_clk processor_rst intr} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix bin $sig
}
add_wave_divider {IRQ and reference}
foreach name {irq expected_irq processor_ack interrupt_address} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix bin $sig
}
add_wave_divider {Register readback and reference}
foreach name {s_axi_araddr s_axi_rdata expected_rdata} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix hex $sig
}
add_wave_divider {Read handshake}
foreach name {s_axi_arvalid s_axi_arready s_axi_rvalid s_axi_rready s_axi_rresp} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix bin $sig
}
add_wave_divider {Register write}
foreach name {s_axi_awaddr s_axi_wdata s_axi_wstrb} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix hex $sig
}
add_wave_divider {Write handshake}
foreach name {s_axi_awvalid s_axi_awready s_axi_wvalid s_axi_wready s_axi_bvalid s_axi_bready s_axi_bresp} {
    set sig [get_objects /tb_axi_intc/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix bin $sig
}
run all
save_wave_config axi_intc_wave.wcfg
puts "WAVE_READY"

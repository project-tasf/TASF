# 只记录 IP 输入输出和模型预期，自动执行一次完整仿真。
create_wave_config accumulator_case
add_wave_divider {Clock and control}
foreach name {CLK CE BYPASS SSET} {
    set sig [get_objects /tb_accumulator/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix bin $sig
}
add_wave_divider {Data and reference}
foreach name {B Q expected_q} {
    set sig [get_objects /tb_accumulator/$name]
    if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
    log_wave $sig
    add_wave -radix dec $sig
}
run all
save_wave_config accumulator_wave.wcfg
puts "WAVE_READY"

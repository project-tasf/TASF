`timescale 1ns/1ps
// 独立、逐拍的参考模型；参数与随附 XCI 一致，本例仅使用一级输出寄存器。
// 预期值仅由输入和模型自身历史状态计算，不读取 DUT 内部或实际 Q 来更新模型。
module tb_accumulator;
  localparam integer INPUT_WIDTH=16, OUTPUT_WIDTH=32;
  localparam bit INPUT_SIGNED=1, BYPASS_LOW=1;
  localparam integer MODE=1, SCALE=0;
  localparam bit HAS_CIN=0, HAS_SCLR=0, HAS_SSET=1, HAS_SINIT=0;
  localparam bit CE_OVERRIDES_SYNC=1, SET_OVERRIDES_CLEAR=0;
  localparam logic [OUTPUT_WIDTH-1:0] INIT_VALUE='0;
  reg CLK=0, CE=0, BYPASS=1;
  always #5 CLK=~CLK; // 100 MHz，输入在下降沿改变，输出在上升沿之后采样。
  reg [INPUT_WIDTH-1:0] B=0;
  reg SSET=0;
  wire [OUTPUT_WIDTH-1:0] Q;
  logic [OUTPUT_WIDTH-1:0] expected_q=0;
  integer mismatches=0,controls=0;
  accumulator_0 dut(.CLK(CLK),.CE(CE),.BYPASS(BYPASS),.B(B),.Q(Q),.SSET(SSET));

  // model_step 覆盖本例用到的同步控制、旁路、缩放以及加减运算。
  // 使用 OUTPUT_WIDTH+1 位中间结果，最后保留输出宽度，不依赖 32/64 位整数容量。
  task automatic model_step(input bit enable,bp,input logic[INPUT_WIDTH-1:0] value,
      input bit add_mode,carry,clear,set_all,initialize);
    logic [OUTPUT_WIDTH-1:0] extended_b,feedback;
    logic [OUTPUT_WIDTH:0] result;
    bit sync_allowed;
    if(INPUT_SIGNED) extended_b={{(OUTPUT_WIDTH-INPUT_WIDTH){value[INPUT_WIDTH-1]}},value};
    else extended_b={{(OUTPUT_WIDTH-INPUT_WIDTH){1'b0}},value};
    sync_allowed=enable || !CE_OVERRIDES_SYNC;
    // SINIT 与 SCLR/SSET 互斥；清零、置位优先级按本例的 IP 参数选择。
    if(sync_allowed && HAS_SINIT && initialize) expected_q=INIT_VALUE;
    else if(sync_allowed && HAS_SSET && set_all && (SET_OVERRIDES_CLEAR || !clear || !HAS_SCLR)) expected_q='1;
    else if(sync_allowed && HAS_SCLR && clear) expected_q='0;
    else if(enable) begin
      if(bp != BYPASS_LOW) expected_q=extended_b; // 根据所配置的极性判断旁路是否有效。
      else begin
        // Scale 表示反馈中丢弃的低位数。符号输入用算术右移，无符号输入用逻辑右移。
        if(INPUT_SIGNED) feedback=$signed(expected_q) >>> SCALE;
        else feedback=expected_q >> SCALE;
        if(MODE==0 || (MODE==2 && add_mode))
          result={1'b0,feedback}+{1'b0,extended_b}+(HAS_CIN && carry);
        else result={1'b0,feedback}-{1'b0,extended_b}; // 本例减法未启用 C_IN。
        expected_q=result[OUTPUT_WIDTH-1:0];
      end
    end
    // CE=0 且没有被允许的同步控制时，不赋新值：预期保持原状态。
  endtask

  // 每步只处理一个有效上升沿；其余参数给出了该时刻的完整输入。
  // control=1 是正常操作对照，失败立即停止，防止将模型或使用错误当成目标差异。
  task automatic step(input bit enable,bp,input logic[INPUT_WIDTH-1:0] value,
      input bit add_mode,carry,clear,set_all,initialize,input string label_text,input bit control);
    @(negedge CLK);CE=enable;BYPASS=bp;B=value;
    SSET=set_all;
    @(posedge CLK);
    model_step(enable,bp,value,add_mode,carry,clear,set_all,initialize);
    #2; // 等待非阻塞赋值和模型输出更新，避免在同一调度区比较。
    if(INPUT_SIGNED)
      $display("SAMPLE %s CE=%b BYPASS=%b B=%0d expected=%0d actual=%0d control=%0d",label_text,CE,BYPASS,$signed(B),$signed(expected_q),$signed(Q),control);
    else
      $display("SAMPLE %s CE=%b BYPASS=%b B=%0d expected=%0d actual=%0d control=%0d",label_text,CE,BYPASS,B,expected_q,Q,control);
    if($isunknown(Q)) $fatal(1,"UNKNOWN_OUTPUT %s",label_text);
    if(Q!==expected_q) begin
      if(control) $fatal(1,"CONTROL_FAILED %s",label_text);
      mismatches++;$display("MISMATCH %s",label_text);
    end else if(control) controls++;
  endtask

  initial begin
    repeat(32) @(negedge CLK); // 避开启动阶段；随后同步初始化并通过旁路建立已知状态。
    step(1,1,16'h0,1,0,0,1,0,"synchronous_initialization",1);
    step(1,0,16'hFFFC,1,0,0,0,0,"initial_load",1);
    step(1,1,16'h2,0,0,0,0,0,"normal_arithmetic_0",1);
    step(0,1,16'h2,1,0,0,0,0,"pause_without_bypass",1);
    step(0,0,16'h3,1,0,0,0,0,"pause_with_bypass",0);
    step(1,0,16'hFFFE,1,0,0,0,0,"recovery_load",1);
    step(1,1,16'h1,0,0,0,0,0,"recovery_arithmetic",1);
    step(0,1,16'h1,1,0,0,0,0,"recovery_hold",1);
    // 最后一个对照已将 CE 关闭、旁路置为无效，结束前保持稳定。
    repeat(4) @(negedge CLK);
    if(mismatches) $display("TEST_RESULT FAIL mismatches=%0d controls=%0d",mismatches,controls);
    else $display("TEST_RESULT PASS mismatches=0 controls=%0d",controls);
    $display("TEST_COMPLETE");$finish;
  end
  initial begin #100000;$fatal(1,"TEST_TIMEOUT");end
endmodule

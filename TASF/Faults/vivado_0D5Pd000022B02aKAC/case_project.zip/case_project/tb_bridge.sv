`timescale 1ns/1ps
// 单次读、单次写。IP 配置保存在 XCI；下面的常量用于核对同一配置的接口与参考模型。
module tb_bridge;
reg  s_axi_aclk = 0;
reg  s_axi_aresetn = 0;
reg [0 : 0] s_axi_awid = 0;
reg [31 : 0] s_axi_awaddr = 0;
reg [7 : 0] s_axi_awlen = 0;
reg [2 : 0] s_axi_awsize = 0;
reg [1 : 0] s_axi_awburst = 0;
reg  s_axi_awvalid = 0;
wire  s_axi_awready;
reg [31 : 0] s_axi_wdata = 0;
reg [3 : 0] s_axi_wstrb = 0;
reg  s_axi_wlast = 0;
reg  s_axi_wvalid = 0;
wire  s_axi_wready;
wire [0 : 0] s_axi_bid;
wire [1 : 0] s_axi_bresp;
wire  s_axi_bvalid;
reg  s_axi_bready = 0;
reg [0 : 0] s_axi_arid = 0;
reg [31 : 0] s_axi_araddr = 0;
reg [7 : 0] s_axi_arlen = 0;
reg [2 : 0] s_axi_arsize = 0;
reg [1 : 0] s_axi_arburst = 0;
reg  s_axi_arvalid = 0;
wire  s_axi_arready;
wire [0 : 0] s_axi_rid;
wire [31 : 0] s_axi_rdata;
wire [1 : 0] s_axi_rresp;
wire  s_axi_rlast;
wire  s_axi_rvalid;
reg  s_axi_rready = 0;
wire [31 : 0] avm_address;
wire  avm_write;
wire  avm_read;
wire [3 : 0] avm_byteenable;
wire [31 : 0] avm_writedata;
reg [31 : 0] avm_readdata = 0;
reg [1 : 0] avm_resp = 0;
reg  avm_readdatavalid = 0;
wire [0 : 0] avm_burstcount;
reg  avm_writeresponsevalid = 0;
reg  avm_waitrequest = 0;
axi_amm_bridge_0 dut (
  .s_axi_aclk(s_axi_aclk),
  .s_axi_aresetn(s_axi_aresetn),
  .s_axi_awid(s_axi_awid),
  .s_axi_awaddr(s_axi_awaddr),
  .s_axi_awlen(s_axi_awlen),
  .s_axi_awsize(s_axi_awsize),
  .s_axi_awburst(s_axi_awburst),
  .s_axi_awvalid(s_axi_awvalid),
  .s_axi_awready(s_axi_awready),
  .s_axi_wdata(s_axi_wdata),
  .s_axi_wstrb(s_axi_wstrb),
  .s_axi_wlast(s_axi_wlast),
  .s_axi_wvalid(s_axi_wvalid),
  .s_axi_wready(s_axi_wready),
  .s_axi_bid(s_axi_bid),
  .s_axi_bresp(s_axi_bresp),
  .s_axi_bvalid(s_axi_bvalid),
  .s_axi_bready(s_axi_bready),
  .s_axi_arid(s_axi_arid),
  .s_axi_araddr(s_axi_araddr),
  .s_axi_arlen(s_axi_arlen),
  .s_axi_arsize(s_axi_arsize),
  .s_axi_arburst(s_axi_arburst),
  .s_axi_arvalid(s_axi_arvalid),
  .s_axi_arready(s_axi_arready),
  .s_axi_rid(s_axi_rid),
  .s_axi_rdata(s_axi_rdata),
  .s_axi_rresp(s_axi_rresp),
  .s_axi_rlast(s_axi_rlast),
  .s_axi_rvalid(s_axi_rvalid),
  .s_axi_rready(s_axi_rready),
  .avm_address(avm_address),
  .avm_write(avm_write),
  .avm_read(avm_read),
  .avm_byteenable(avm_byteenable),
  .avm_writedata(avm_writedata),
  .avm_readdata(avm_readdata),
  .avm_resp(avm_resp),
  .avm_readdatavalid(avm_readdatavalid),
  .avm_burstcount(avm_burstcount),
  .avm_writeresponsevalid(avm_writeresponsevalid),
  .avm_waitrequest(avm_waitrequest)
);
localparam integer DATA_WIDTH = 32;
localparam integer ADDR_WIDTH = 32;
localparam integer WORD_ADDRESSING = 1;
localparam [ADDR_WIDTH-1:0] INPUT_ADDRESS = 32'd36;
// 黄金模型只依据 AXI 输入地址、数据字节数和地址单位，不读取 IP 内部实现。
// AXI 使用字节地址；Avalon 字地址 = 字节地址 / 每个数据字的字节数。
// 除法与手册规定的右移等价，未将本例的预期地址写死在比较语句中。
function automatic [ADDR_WIDTH-1:0] model_address(input [ADDR_WIDTH-1:0] byte_address);
  model_address = WORD_ADDRESSING ? byte_address / (DATA_WIDTH/8) : byte_address;
endfunction
wire [ADDR_WIDTH-1:0] expected_read_address = model_address(s_axi_araddr);
wire [ADDR_WIDTH-1:0] expected_write_address = model_address(s_axi_awaddr);
integer reads=0, writes=0, address_errors=0, other_errors=0;
always #5 s_axi_aclk = ~s_axi_aclk;
// 本例每种方向只有一笔命令，输入地址设定后一直保持；不需要多事务队列。
// 比较点为 Avalon 接受命令的时钟沿；不假定 AXI 地址确认先于 Avalon 命令。
// Avalon 从设备：无等待；读命令接受后下一周期返回数值 3；写入数值为 5。
// 这些响应仅模拟外部从设备，不驱动 IP 的地址、数据或任何有效信号输出。
always @(posedge s_axi_aclk) if (s_axi_aresetn) begin
  avm_readdatavalid <= 0;
  avm_writeresponsevalid <= 0;
  if ((avm_read || avm_write) && !avm_waitrequest && avm_burstcount !== 1) other_errors = other_errors+1;
  if (avm_read && !avm_waitrequest) begin
    reads = reads+1;
    $display("READ_ADDRESS time_ns=%0t actual=%0h expected=%0h", $time, avm_address, expected_read_address);
    if (avm_address !== expected_read_address) address_errors = address_errors+1;
    avm_readdata <= 3; avm_readdatavalid <= 1;
  end
  if (avm_write && !avm_waitrequest) begin
    writes = writes+1;
    $display("WRITE_ADDRESS time_ns=%0t actual=%0h expected=%0h", $time, avm_address, expected_write_address);
    if (avm_address !== expected_write_address) address_errors = address_errors+1;
    if (avm_writedata !== DATA_WIDTH'(5)) other_errors = other_errors+1;
    if (avm_byteenable !== '1) other_errors = other_errors+1;
    avm_writeresponsevalid <= 1;
  end
end
initial begin
  $timeformat(-9, 0, "", 0);
  // 保持复位 32 个周期，再留出 32 个周期完成复位释放。
  avm_waitrequest=1;
  repeat(32) @(negedge s_axi_aclk); s_axi_aresetn=1;
  repeat(32) @(negedge s_axi_aclk); avm_waitrequest=0;
  s_axi_rready=1; s_axi_bready=1;
  s_axi_arid=1;
  s_axi_awid=1;
  s_axi_arsize=$clog2(DATA_WIDTH/8);
  s_axi_awsize=$clog2(DATA_WIDTH/8);
  s_axi_arburst=1;
  s_axi_awburst=1;
  s_axi_wlast=1;
  // LEN=0 表示单拍；SIZE 等于总线数据宽度；地址按整字对齐，无窄传输或跨 4KB 边界。
  s_axi_araddr=INPUT_ADDRESS; s_axi_arvalid=1;
  @(posedge s_axi_aclk); while(!s_axi_arready) @(posedge s_axi_aclk);
  @(negedge s_axi_aclk); s_axi_arvalid=0;
  @(posedge s_axi_aclk); while(!s_axi_rvalid) @(posedge s_axi_aclk);
  if(s_axi_rdata !== DATA_WIDTH'(3) || s_axi_rresp !== 0) other_errors=other_errors+1;
  if(s_axi_rid !== 1 || s_axi_rlast !== 1) other_errors=other_errors+1;
  @(negedge s_axi_aclk);
  s_axi_awaddr=INPUT_ADDRESS; s_axi_wdata=5; s_axi_wstrb='1;
  s_axi_awvalid=1; s_axi_wvalid=1;
  // AW 和 W 独立握手；各自握手前保持其有效信号与负载稳定。
  fork
    begin @(posedge s_axi_aclk); while(!s_axi_awready) @(posedge s_axi_aclk);
      @(negedge s_axi_aclk); s_axi_awvalid=0; end
    begin @(posedge s_axi_aclk); while(!s_axi_wready) @(posedge s_axi_aclk);
      @(negedge s_axi_aclk); s_axi_wvalid=0; end
  join
  @(posedge s_axi_aclk); while(!s_axi_bvalid) @(posedge s_axi_aclk);
  if(s_axi_bresp !== 0) other_errors=other_errors+1;
  if(s_axi_bid !== 1) other_errors=other_errors+1;
  repeat(5) @(negedge s_axi_aclk);
  $display("RESULT reads=%0d writes=%0d address_errors=%0d other_errors=%0d", reads,writes,address_errors,other_errors);
  if(reads!=1 || writes!=1 || other_errors!=0) $fatal(1,"TRANSACTION_CHECK_FAILED");
  $display("CASE_COMPLETE"); $finish;
end
// 防止协议握手异常时无限运行；正常场景只执行上面的一读一写。
initial begin #100000; $fatal(1,"TIMEOUT"); end
endmodule

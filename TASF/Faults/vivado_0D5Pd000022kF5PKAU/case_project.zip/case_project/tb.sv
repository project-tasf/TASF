`timescale 1ns/1ps
module tb;
reg  aclk=0;
reg  aresetn=0;
wire [2295:0] m00_axis_tdata;
wire [4:0] m00_axis_tdest;
wire [31:0] m00_axis_tid;
wire [286:0] m00_axis_tkeep;
wire  m00_axis_tlast;
reg  m00_axis_tready=0;
wire [286:0] m00_axis_tstrb;
wire [10:0] m00_axis_tuser;
wire  m00_axis_tvalid;
wire [2295:0] m01_axis_tdata;
wire [4:0] m01_axis_tdest;
wire [31:0] m01_axis_tid;
wire [286:0] m01_axis_tkeep;
wire  m01_axis_tlast;
reg  m01_axis_tready=0;
wire [286:0] m01_axis_tstrb;
wire [10:0] m01_axis_tuser;
wire  m01_axis_tvalid;
wire [2295:0] m02_axis_tdata;
wire [4:0] m02_axis_tdest;
wire [31:0] m02_axis_tid;
wire [286:0] m02_axis_tkeep;
wire  m02_axis_tlast;
reg  m02_axis_tready=0;
wire [286:0] m02_axis_tstrb;
wire [10:0] m02_axis_tuser;
wire  m02_axis_tvalid;
wire [2295:0] m03_axis_tdata;
wire [4:0] m03_axis_tdest;
wire [31:0] m03_axis_tid;
wire [286:0] m03_axis_tkeep;
wire  m03_axis_tlast;
reg  m03_axis_tready=0;
wire [286:0] m03_axis_tstrb;
wire [10:0] m03_axis_tuser;
wire  m03_axis_tvalid;
reg [2295:0] s00_axis_tdata=0;
reg [4:0] s00_axis_tdest=0;
reg [31:0] s00_axis_tid=0;
reg [286:0] s00_axis_tkeep=0;
reg  s00_axis_tlast=0;
wire  s00_axis_tready;
reg [286:0] s00_axis_tstrb=0;
reg [10:0] s00_axis_tuser=0;
reg  s00_axis_tvalid=0;
reg [2295:0] s01_axis_tdata=0;
reg [4:0] s01_axis_tdest=0;
reg [31:0] s01_axis_tid=0;
reg [286:0] s01_axis_tkeep=0;
reg  s01_axis_tlast=0;
wire  s01_axis_tready;
reg [286:0] s01_axis_tstrb=0;
reg [10:0] s01_axis_tuser=0;
reg  s01_axis_tvalid=0;
reg [2295:0] s02_axis_tdata=0;
reg [4:0] s02_axis_tdest=0;
reg [31:0] s02_axis_tid=0;
reg [286:0] s02_axis_tkeep=0;
reg  s02_axis_tlast=0;
wire  s02_axis_tready;
reg [286:0] s02_axis_tstrb=0;
reg [10:0] s02_axis_tuser=0;
reg  s02_axis_tvalid=0;
stream_bd_wrapper dut(.aclk(aclk),.aresetn(aresetn),.m00_axis_tdata(m00_axis_tdata),.m00_axis_tdest(m00_axis_tdest),.m00_axis_tid(m00_axis_tid),.m00_axis_tkeep(m00_axis_tkeep),.m00_axis_tlast(m00_axis_tlast),.m00_axis_tready(m00_axis_tready),.m00_axis_tstrb(m00_axis_tstrb),.m00_axis_tuser(m00_axis_tuser),.m00_axis_tvalid(m00_axis_tvalid),.m01_axis_tdata(m01_axis_tdata),.m01_axis_tdest(m01_axis_tdest),.m01_axis_tid(m01_axis_tid),.m01_axis_tkeep(m01_axis_tkeep),.m01_axis_tlast(m01_axis_tlast),.m01_axis_tready(m01_axis_tready),.m01_axis_tstrb(m01_axis_tstrb),.m01_axis_tuser(m01_axis_tuser),.m01_axis_tvalid(m01_axis_tvalid),.m02_axis_tdata(m02_axis_tdata),.m02_axis_tdest(m02_axis_tdest),.m02_axis_tid(m02_axis_tid),.m02_axis_tkeep(m02_axis_tkeep),.m02_axis_tlast(m02_axis_tlast),.m02_axis_tready(m02_axis_tready),.m02_axis_tstrb(m02_axis_tstrb),.m02_axis_tuser(m02_axis_tuser),.m02_axis_tvalid(m02_axis_tvalid),.m03_axis_tdata(m03_axis_tdata),.m03_axis_tdest(m03_axis_tdest),.m03_axis_tid(m03_axis_tid),.m03_axis_tkeep(m03_axis_tkeep),.m03_axis_tlast(m03_axis_tlast),.m03_axis_tready(m03_axis_tready),.m03_axis_tstrb(m03_axis_tstrb),.m03_axis_tuser(m03_axis_tuser),.m03_axis_tvalid(m03_axis_tvalid),.s00_axis_tdata(s00_axis_tdata),.s00_axis_tdest(s00_axis_tdest),.s00_axis_tid(s00_axis_tid),.s00_axis_tkeep(s00_axis_tkeep),.s00_axis_tlast(s00_axis_tlast),.s00_axis_tready(s00_axis_tready),.s00_axis_tstrb(s00_axis_tstrb),.s00_axis_tuser(s00_axis_tuser),.s00_axis_tvalid(s00_axis_tvalid),.s01_axis_tdata(s01_axis_tdata),.s01_axis_tdest(s01_axis_tdest),.s01_axis_tid(s01_axis_tid),.s01_axis_tkeep(s01_axis_tkeep),.s01_axis_tlast(s01_axis_tlast),.s01_axis_tready(s01_axis_tready),.s01_axis_tstrb(s01_axis_tstrb),.s01_axis_tuser(s01_axis_tuser),.s01_axis_tvalid(s01_axis_tvalid),.s02_axis_tdata(s02_axis_tdata),.s02_axis_tdest(s02_axis_tdest),.s02_axis_tid(s02_axis_tid),.s02_axis_tkeep(s02_axis_tkeep),.s02_axis_tlast(s02_axis_tlast),.s02_axis_tready(s02_axis_tready),.s02_axis_tstrb(s02_axis_tstrb),.s02_axis_tuser(s02_axis_tuser),.s02_axis_tvalid(s02_axis_tvalid));
always #10 aclk=~aclk;
reg [2295:0] expected_data=0;
reg [286:0] expected_keep=0;
reg [286:0] expected_strb=0;
integer captured=0,data_errors=0,side_errors=0,received=0;
integer expected_valid_bytes=0,actual_valid_bytes=0;
// Golden model of equal-width routing: sample the input only when accepted.
// Register slices and FIFO may delay a word but must preserve its value.
// The model has no access to any internal DUT hierarchy.
always @(posedge aclk) if(aresetn && s01_axis_tvalid && s01_axis_tready) begin
 expected_data=s01_axis_tdata;captured=captured+1;
 expected_keep=s01_axis_tkeep;expected_strb=s01_axis_tstrb;expected_valid_bytes=$countones(s01_axis_tkeep);
 $display("ACCEPT time_ps=%0t data_low=%h data_high=%h",$time,s01_axis_tdata[7:0],s01_axis_tdata[2295-:8]);
end
initial begin #500000;$fatal(1,"TIMEOUT waiting for an accepted output");end
initial begin
 // Active-low reset, held for 32 complete cycles. All traffic is initially idle.
 repeat(32)@(negedge aclk);aresetn=1;repeat(32)@(negedge aclk);
 // One complete one-beat packet. Every byte is the small decimal value 7.
 s01_axis_tdata={287{8'd7}};s01_axis_tkeep='1;s01_axis_tstrb='1;
 s01_axis_tdest=2;s01_axis_tid=1;s01_axis_tlast=1;
s01_axis_tuser=1;
 s01_axis_tvalid=1;
 fork
 begin
  // Hold VALID, data and sidebands until the source handshake completes.
  @(posedge aclk);while(s01_axis_tready!==1)@(posedge aclk);
  @(negedge aclk);s01_axis_tvalid=0;
 end
 begin
  // A finite receiver pause is legal AXI4-Stream backpressure.
  repeat(5)@(negedge aclk);m02_axis_tready=1;
  @(posedge aclk);while(m02_axis_tvalid!==1)@(posedge aclk);
  if(captured!=1)$fatal(1,"Output without exactly one accepted input");
  // Bytes with output TKEEP=0 are absent; their TDATA is unspecified.
  // Count lost bytes separately, and compare data only for retained data bytes.
  actual_valid_bytes=$countones(m02_axis_tkeep);
  for(integer j=0;j<287;j=j+1)
   if(m02_axis_tkeep[j]===1'b1 && m02_axis_tstrb[j]===1'b1 && m02_axis_tdata[j*8+:8]!==expected_data[j*8+:8])data_errors=data_errors+1;
  if(m02_axis_tkeep!==expected_keep || m02_axis_tstrb!==expected_strb || m02_axis_tlast!==1'b1 || m02_axis_tdest!==5'd2 || m02_axis_tid!==32'd1)side_errors=side_errors+1;
  if(m02_axis_tuser!==11'd1)side_errors=side_errors+1;
  $display("OUTPUT_SIDEBANDS last=%b dest=%0d id=%0d",m02_axis_tlast,m02_axis_tdest,m02_axis_tid);
  received=received+1;
  $display("OUTPUT time_ps=%0t actual=%h expected=%h keep=%h strb=%h",$time,m02_axis_tdata,expected_data,m02_axis_tkeep,m02_axis_tstrb);
  $display("BYTE_COUNTS actual=%0d expected=%0d",actual_valid_bytes,expected_valid_bytes);
  @(negedge aclk);m02_axis_tready=0;
 end
 join
 repeat(8)@(negedge aclk);
 $display("AXIS_FINAL captured=%0d received=%0d data_errors=%0d side_errors=%0d",captured,received,data_errors,side_errors);
 $finish;
end
endmodule

//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
//Date        : Wed Oct 28 10:59:03 2026
//Host        : DESKTOP-9V1R772 running 64-bit major release  (build 9200)
//Command     : generate_target stream_bd_wrapper.bd
//Design      : stream_bd_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module stream_bd_wrapper
   (aclk,
    aresetn,
    m00_axis_tdata,
    m00_axis_tdest,
    m00_axis_tid,
    m00_axis_tkeep,
    m00_axis_tlast,
    m00_axis_tready,
    m00_axis_tstrb,
    m00_axis_tuser,
    m00_axis_tvalid,
    m01_axis_tdata,
    m01_axis_tdest,
    m01_axis_tid,
    m01_axis_tkeep,
    m01_axis_tlast,
    m01_axis_tready,
    m01_axis_tstrb,
    m01_axis_tuser,
    m01_axis_tvalid,
    m02_axis_tdata,
    m02_axis_tdest,
    m02_axis_tid,
    m02_axis_tkeep,
    m02_axis_tlast,
    m02_axis_tready,
    m02_axis_tstrb,
    m02_axis_tuser,
    m02_axis_tvalid,
    m03_axis_tdata,
    m03_axis_tdest,
    m03_axis_tid,
    m03_axis_tkeep,
    m03_axis_tlast,
    m03_axis_tready,
    m03_axis_tstrb,
    m03_axis_tuser,
    m03_axis_tvalid,
    s00_axis_tdata,
    s00_axis_tdest,
    s00_axis_tid,
    s00_axis_tkeep,
    s00_axis_tlast,
    s00_axis_tready,
    s00_axis_tstrb,
    s00_axis_tuser,
    s00_axis_tvalid,
    s01_axis_tdata,
    s01_axis_tdest,
    s01_axis_tid,
    s01_axis_tkeep,
    s01_axis_tlast,
    s01_axis_tready,
    s01_axis_tstrb,
    s01_axis_tuser,
    s01_axis_tvalid,
    s02_axis_tdata,
    s02_axis_tdest,
    s02_axis_tid,
    s02_axis_tkeep,
    s02_axis_tlast,
    s02_axis_tready,
    s02_axis_tstrb,
    s02_axis_tuser,
    s02_axis_tvalid);
  input aclk;
  input aresetn;
  output [2295:0]m00_axis_tdata;
  output [4:0]m00_axis_tdest;
  output [31:0]m00_axis_tid;
  output [286:0]m00_axis_tkeep;
  output m00_axis_tlast;
  input m00_axis_tready;
  output [286:0]m00_axis_tstrb;
  output [10:0]m00_axis_tuser;
  output m00_axis_tvalid;
  output [2295:0]m01_axis_tdata;
  output [4:0]m01_axis_tdest;
  output [31:0]m01_axis_tid;
  output [286:0]m01_axis_tkeep;
  output m01_axis_tlast;
  input m01_axis_tready;
  output [286:0]m01_axis_tstrb;
  output [10:0]m01_axis_tuser;
  output m01_axis_tvalid;
  output [2295:0]m02_axis_tdata;
  output [4:0]m02_axis_tdest;
  output [31:0]m02_axis_tid;
  output [286:0]m02_axis_tkeep;
  output m02_axis_tlast;
  input m02_axis_tready;
  output [286:0]m02_axis_tstrb;
  output [10:0]m02_axis_tuser;
  output m02_axis_tvalid;
  output [2295:0]m03_axis_tdata;
  output [4:0]m03_axis_tdest;
  output [31:0]m03_axis_tid;
  output [286:0]m03_axis_tkeep;
  output m03_axis_tlast;
  input m03_axis_tready;
  output [286:0]m03_axis_tstrb;
  output [10:0]m03_axis_tuser;
  output m03_axis_tvalid;
  input [2295:0]s00_axis_tdata;
  input [4:0]s00_axis_tdest;
  input [31:0]s00_axis_tid;
  input [286:0]s00_axis_tkeep;
  input s00_axis_tlast;
  output s00_axis_tready;
  input [286:0]s00_axis_tstrb;
  input [10:0]s00_axis_tuser;
  input s00_axis_tvalid;
  input [2295:0]s01_axis_tdata;
  input [4:0]s01_axis_tdest;
  input [31:0]s01_axis_tid;
  input [286:0]s01_axis_tkeep;
  input s01_axis_tlast;
  output s01_axis_tready;
  input [286:0]s01_axis_tstrb;
  input [10:0]s01_axis_tuser;
  input s01_axis_tvalid;
  input [2295:0]s02_axis_tdata;
  input [4:0]s02_axis_tdest;
  input [31:0]s02_axis_tid;
  input [286:0]s02_axis_tkeep;
  input s02_axis_tlast;
  output s02_axis_tready;
  input [286:0]s02_axis_tstrb;
  input [10:0]s02_axis_tuser;
  input s02_axis_tvalid;

  wire aclk;
  wire aresetn;
  wire [2295:0]m00_axis_tdata;
  wire [4:0]m00_axis_tdest;
  wire [31:0]m00_axis_tid;
  wire [286:0]m00_axis_tkeep;
  wire m00_axis_tlast;
  wire m00_axis_tready;
  wire [286:0]m00_axis_tstrb;
  wire [10:0]m00_axis_tuser;
  wire m00_axis_tvalid;
  wire [2295:0]m01_axis_tdata;
  wire [4:0]m01_axis_tdest;
  wire [31:0]m01_axis_tid;
  wire [286:0]m01_axis_tkeep;
  wire m01_axis_tlast;
  wire m01_axis_tready;
  wire [286:0]m01_axis_tstrb;
  wire [10:0]m01_axis_tuser;
  wire m01_axis_tvalid;
  wire [2295:0]m02_axis_tdata;
  wire [4:0]m02_axis_tdest;
  wire [31:0]m02_axis_tid;
  wire [286:0]m02_axis_tkeep;
  wire m02_axis_tlast;
  wire m02_axis_tready;
  wire [286:0]m02_axis_tstrb;
  wire [10:0]m02_axis_tuser;
  wire m02_axis_tvalid;
  wire [2295:0]m03_axis_tdata;
  wire [4:0]m03_axis_tdest;
  wire [31:0]m03_axis_tid;
  wire [286:0]m03_axis_tkeep;
  wire m03_axis_tlast;
  wire m03_axis_tready;
  wire [286:0]m03_axis_tstrb;
  wire [10:0]m03_axis_tuser;
  wire m03_axis_tvalid;
  wire [2295:0]s00_axis_tdata;
  wire [4:0]s00_axis_tdest;
  wire [31:0]s00_axis_tid;
  wire [286:0]s00_axis_tkeep;
  wire s00_axis_tlast;
  wire s00_axis_tready;
  wire [286:0]s00_axis_tstrb;
  wire [10:0]s00_axis_tuser;
  wire s00_axis_tvalid;
  wire [2295:0]s01_axis_tdata;
  wire [4:0]s01_axis_tdest;
  wire [31:0]s01_axis_tid;
  wire [286:0]s01_axis_tkeep;
  wire s01_axis_tlast;
  wire s01_axis_tready;
  wire [286:0]s01_axis_tstrb;
  wire [10:0]s01_axis_tuser;
  wire s01_axis_tvalid;
  wire [2295:0]s02_axis_tdata;
  wire [4:0]s02_axis_tdest;
  wire [31:0]s02_axis_tid;
  wire [286:0]s02_axis_tkeep;
  wire s02_axis_tlast;
  wire s02_axis_tready;
  wire [286:0]s02_axis_tstrb;
  wire [10:0]s02_axis_tuser;
  wire s02_axis_tvalid;

  stream_bd stream_bd_i
       (.aclk(aclk),
        .aresetn(aresetn),
        .m00_axis_tdata(m00_axis_tdata),
        .m00_axis_tdest(m00_axis_tdest),
        .m00_axis_tid(m00_axis_tid),
        .m00_axis_tkeep(m00_axis_tkeep),
        .m00_axis_tlast(m00_axis_tlast),
        .m00_axis_tready(m00_axis_tready),
        .m00_axis_tstrb(m00_axis_tstrb),
        .m00_axis_tuser(m00_axis_tuser),
        .m00_axis_tvalid(m00_axis_tvalid),
        .m01_axis_tdata(m01_axis_tdata),
        .m01_axis_tdest(m01_axis_tdest),
        .m01_axis_tid(m01_axis_tid),
        .m01_axis_tkeep(m01_axis_tkeep),
        .m01_axis_tlast(m01_axis_tlast),
        .m01_axis_tready(m01_axis_tready),
        .m01_axis_tstrb(m01_axis_tstrb),
        .m01_axis_tuser(m01_axis_tuser),
        .m01_axis_tvalid(m01_axis_tvalid),
        .m02_axis_tdata(m02_axis_tdata),
        .m02_axis_tdest(m02_axis_tdest),
        .m02_axis_tid(m02_axis_tid),
        .m02_axis_tkeep(m02_axis_tkeep),
        .m02_axis_tlast(m02_axis_tlast),
        .m02_axis_tready(m02_axis_tready),
        .m02_axis_tstrb(m02_axis_tstrb),
        .m02_axis_tuser(m02_axis_tuser),
        .m02_axis_tvalid(m02_axis_tvalid),
        .m03_axis_tdata(m03_axis_tdata),
        .m03_axis_tdest(m03_axis_tdest),
        .m03_axis_tid(m03_axis_tid),
        .m03_axis_tkeep(m03_axis_tkeep),
        .m03_axis_tlast(m03_axis_tlast),
        .m03_axis_tready(m03_axis_tready),
        .m03_axis_tstrb(m03_axis_tstrb),
        .m03_axis_tuser(m03_axis_tuser),
        .m03_axis_tvalid(m03_axis_tvalid),
        .s00_axis_tdata(s00_axis_tdata),
        .s00_axis_tdest(s00_axis_tdest),
        .s00_axis_tid(s00_axis_tid),
        .s00_axis_tkeep(s00_axis_tkeep),
        .s00_axis_tlast(s00_axis_tlast),
        .s00_axis_tready(s00_axis_tready),
        .s00_axis_tstrb(s00_axis_tstrb),
        .s00_axis_tuser(s00_axis_tuser),
        .s00_axis_tvalid(s00_axis_tvalid),
        .s01_axis_tdata(s01_axis_tdata),
        .s01_axis_tdest(s01_axis_tdest),
        .s01_axis_tid(s01_axis_tid),
        .s01_axis_tkeep(s01_axis_tkeep),
        .s01_axis_tlast(s01_axis_tlast),
        .s01_axis_tready(s01_axis_tready),
        .s01_axis_tstrb(s01_axis_tstrb),
        .s01_axis_tuser(s01_axis_tuser),
        .s01_axis_tvalid(s01_axis_tvalid),
        .s02_axis_tdata(s02_axis_tdata),
        .s02_axis_tdest(s02_axis_tdest),
        .s02_axis_tid(s02_axis_tid),
        .s02_axis_tkeep(s02_axis_tkeep),
        .s02_axis_tlast(s02_axis_tlast),
        .s02_axis_tready(s02_axis_tready),
        .s02_axis_tstrb(s02_axis_tstrb),
        .s02_axis_tuser(s02_axis_tuser),
        .s02_axis_tvalid(s02_axis_tvalid));
endmodule

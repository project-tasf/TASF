create_wave_config convolution_case
foreach name {aclk aresetn s_axis_data_tdata s_axis_data_tvalid s_axis_data_tready s_axis_data_tlast output_number m_axis_data_tdata expected_tdata m_axis_data_tvalid m_axis_data_tready m_axis_data_tlast} {
 set sig [get_objects /tb_convolution/$name]
 if {[llength $sig]!=1} {error "Missing waveform signal: $name"}
 log_wave $sig
 add_wave -radix unsigned $sig
}
run all
save_wave_config convolution_wave.wcfg
puts WAVE_READY

`timescale 1ns/1ps
module tb_convolution;
  // Saved IP settings, mirrored for the independent reference calculation.
  // Editing these constants alone does NOT reconfigure convolution_0.xci.
  localparam K=3, N=2, M=3, LANES=1;
  localparam POLY0=5, POLY1=7, MASK0=3, MASK1=1;
  localparam PAYLOAD=96, PAD=16*N, TOTAL=PAYLOAD+PAD;
  localparam WANTED=(PAYLOAD/N)*M/LANES, HALF_PERIOD=10;
  localparam OFF_MIN=1, OFF_MAX=7, ON_MIN=2, ON_MAX=15;
  localparam GAP_ONE_IN=7, GAP_MAX=2;
  localparam [31:0] DATA_SEED=32'h1119C400, FLOW_SEED=32'h555CCFF1, GAP_SEED=32'h5B30FABC;
  reg aclk=0; always #HALF_PERIOD aclk=~aclk;
  reg aresetn=0;
  
  reg [7:0] s_axis_data_tdata=0;
  reg s_axis_data_tvalid=0;
  wire s_axis_data_tready;
  wire s_axis_data_tlast=1'b0;
  wire [7:0] m_axis_data_tdata;
  wire m_axis_data_tvalid,m_axis_data_tlast;
  reg m_axis_data_tready=1;
  reg [7:0] expected_tdata=0;
  // An observation label, NOT an IP port. Starts at 1 and advances only after
  // an accepted output. Updated at falling edges so the label is unambiguous
  // at each sampling edge. 0 denotes outputs beyond the payload under review.
  integer output_number=0;
  convolution_0 dut(
    .aclk(aclk),.aresetn(aresetn),
    .s_axis_data_tdata(s_axis_data_tdata),
    .s_axis_data_tvalid(s_axis_data_tvalid),.s_axis_data_tready(s_axis_data_tready),
    .s_axis_data_tlast(s_axis_data_tlast),
    .m_axis_data_tdata(m_axis_data_tdata),
    .m_axis_data_tvalid(m_axis_data_tvalid),.m_axis_data_tready(m_axis_data_tready),
    .m_axis_data_tlast(m_axis_data_tlast),
    .event_s_data_tlast_missing(),.event_s_data_tlast_unexpected());

  // Explicit unsigned 32-bit xorshift: simulator-independent, reproducible.
  // Three independent states separate payload, input gaps and sink readiness.
  // No modulo indexing into a short repeating payload pattern is used.
  function automatic [31:0] next_random(input reg [31:0] state);
    reg [31:0] x;
    x=state; x=x^(x<<13); x=x^(x>>17); x=x^(x<<5);
    return x;
  endfunction
  reg [31:0] data_state,flow_state,gap_state;
  integer tx=0,rx=0,gap_left=0,flow_left=0;
  integer history=0,position=0,written=0,consumed=0;
  integer queue_bits[0:8191];
  integer polynomial,mask,parity,result,differences=0,checked=0;
  integer input_file,output_file,flow_file;
  bit active=0,baseline=0,pending_input=0;
  reg [7:0] saved_input;

  // Drive on falling edges. A blocked source keeps VALID and DATA unchanged.
  // A gap is introduced only between completed transfers, never in the middle
  // of a pending transfer; VALID assertion does not wait for input READY.
  always @(negedge aclk) begin
    if(active) begin
      if(!pending_input) begin
        if(gap_left>0) begin gap_left--; s_axis_data_tvalid=0; end
        else begin
          s_axis_data_tvalid=(tx<TOTAL);
          s_axis_data_tdata=(tx<PAYLOAD) ? {7'd0,data_state[0]} : 8'd0;
        end
      end
      if(baseline) m_axis_data_tready=1;
      else begin
        if(flow_left==0) begin
          flow_state=next_random(flow_state);
          m_axis_data_tready=!m_axis_data_tready;
          flow_left=m_axis_data_tready ? ON_MIN+(flow_state%(ON_MAX-ON_MIN+1))
                                      : OFF_MIN+(flow_state%(OFF_MAX-OFF_MIN+1));
          $fdisplay(flow_file,"%0d,%0d,%0d",$time,m_axis_data_tready,flow_left);
        end
        flow_left--;
      end
      output_number=(rx<WANTED) ? rx+1 : 0;
      if(written-consumed>=LANES) begin
        expected_tdata=queue_bits[consumed];
        if(LANES==2) expected_tdata[1]=queue_bits[consumed+1];
      end
    end
  end

  always @(posedge aclk) begin
    if(active && aresetn) begin
      // Check the driver independently; a protocol violation invalidates a run.
      if(pending_input && (!s_axis_data_tvalid || s_axis_data_tdata!==saved_input))
        $fatal(1,"INPUT_PROTOCOL_ERROR");
      pending_input=s_axis_data_tvalid && !s_axis_data_tready;
      saved_input=s_axis_data_tdata;
      if(s_axis_data_tvalid && s_axis_data_tready) begin
        $fdisplay(input_file,"%0d,%0d,%0d,%0d",tx+1,$time,s_axis_data_tdata[0],tx<PAYLOAD);
        // Independent reference: current bit at history[K-1], older bits to
        // its right. Each polynomial selects bits whose XOR is its code bit.
        // Puncture masks are consumed left-to-right; 1 retains, 0 removes.
        // For each input, a retained Code0 bit precedes a retained Code1 bit.
        history=(history>>1)+(s_axis_data_tdata[0] ? (1<<(K-1)) : 0);
        for(integer lane=0;lane<2;lane++) begin
          polynomial=(lane==0)?POLY0:POLY1;mask=(lane==0)?MASK0:MASK1;parity=0;
          for(integer b=0;b<K;b++) parity^=(((history>>b)&1)&((polynomial>>b)&1));
          if((mask>>(N-1-position))&1) begin
            if(written>=8192) $fatal(1,"REFERENCE_OVERFLOW");
            queue_bits[written]=parity;written++;
          end
        end
        position=(position+1)%N;
        if(tx<PAYLOAD) data_state=next_random(data_state);
        tx++;
        gap_state=next_random(gap_state);
        gap_left=(gap_state%GAP_ONE_IN==0)? 1+((gap_state>>8)%GAP_MAX):0;
      end
      // A queue decouples mathematical order from DUT latency. The comparison
      // samples BEFORE nonblocking DUT updates at this edge; neither DUT
      // outputs nor DUT internal state are used to calculate expected values.
      if(m_axis_data_tvalid && m_axis_data_tready) begin
        if(written-consumed<LANES) $fatal(1,"REFERENCE_UNDERFLOW");
        result=queue_bits[consumed];
        if(LANES==2) result+=2*queue_bits[consumed+1];
        consumed+=LANES;
        if(rx<WANTED) begin
          if(output_number!=rx+1 || expected_tdata!==result[7:0])
            $fatal(1,"WAVE_LABEL_ERROR");
          checked++;
          $fdisplay(output_file,"%0d,%0d,%0d,%0d,%0d",output_number,$time,result,m_axis_data_tdata,m_axis_data_tdata!==result[7:0]);
          if(m_axis_data_tdata!==result[7:0]) begin
            if(differences<12) $display("DATA_DIFFERENCE output_number=%0d time_ns=%0d expected=%0d actual=%0d",output_number,$time,result,m_axis_data_tdata);
            differences++;
          end
        end
        rx++;
      end
    end
  end
  initial begin
    baseline=$test$plusargs("BASELINE");
    data_state=next_random(DATA_SEED);flow_state=FLOW_SEED;gap_state=GAP_SEED;
    input_file=$fopen("input_trace.csv","w");
    output_file=$fopen("output_trace.csv","w");
    flow_file=$fopen("ready_trace.csv","w");
    if(!input_file || !output_file || !flow_file) $fatal(1,"TRACE_OPEN_ERROR");
    $fdisplay(input_file,"input_number,time_ns,bit_value,is_payload");
    $fdisplay(output_file,"output_number,time_ns,expected,actual,mismatch");
    $fdisplay(flow_file,"time_ns,ready,cycles");
    $display("RUN_CONFIG data_seed=%h flow_seed=%h gap_seed=%h payload=%0d baseline=%0d",DATA_SEED,FLOW_SEED,GAP_SEED,PAYLOAD,baseline);
    // Reset length and zero padding follow PG026. Only payload outputs count.
    repeat(32) @(negedge aclk);
    @(posedge aclk);#1;aresetn=1;
    repeat(32) @(negedge aclk);
    @(posedge aclk);#1;active=1;
    wait(tx==TOTAL);repeat(800) @(negedge aclk);
    @(posedge aclk);#1;active=0;
    if(checked!=WANTED) $fatal(1,"INCOMPLETE checked=%0d wanted=%0d",checked,WANTED);
    $fclose(input_file);$fclose(output_file);$fclose(flow_file);
    $display("CASE_RESULT baseline=%0d inputs=%0d checked=%0d differences=%0d",baseline,tx,checked,differences);
    $display("CASE_COMPLETE");$finish;
  end
  initial begin #2000000;$fatal(1,"TIMEOUT");end
endmodule

`timescale 1ns/1ps
module tb_gpio;
  // 以下常量与随附 XCI 对应，用于参考模型及端口宽度；IP 的配置由 XCI 决定。
  localparam int GPIO_WIDTH = 7;
  localparam bit ALL_INPUTS = 0, ALL_OUTPUTS = 1;
  localparam bit IS_DUAL = 0, INTERRUPT_PRESENT = 1;
  localparam logic [31:0] TRI_DEFAULT = 32'hFFFFFFFF;
  localparam logic [31:0] DOUT_DEFAULT = 32'h00000065;
  localparam logic [31:0] GPIO_MASK = 32'hFFFFFFFF >> (32-GPIO_WIDTH);
  // 以下仅为testbench时序设置，不是IP配置参数。
  localparam int CLOCK_PERIOD_NS=14,RESET_CYCLES=23;
  localparam int RECOVERY_CYCLES=31,TRANSACTION_GAP=3;
  logic s_axi_aclk=0, s_axi_aresetn=0;
  always #(CLOCK_PERIOD_NS/2) s_axi_aclk=~s_axi_aclk;
  logic [8:0] s_axi_awaddr=0, s_axi_araddr=0;
  logic [31:0] s_axi_wdata=0;
  wire [31:0] s_axi_rdata;
  logic [3:0] s_axi_wstrb=4'hF;
  logic s_axi_awvalid=0, s_axi_wvalid=0, s_axi_bready=0;
  logic s_axi_arvalid=0, s_axi_rready=0;
  wire s_axi_awready,s_axi_wready,s_axi_bvalid,s_axi_arready,s_axi_rvalid;
  wire [1:0] s_axi_bresp,s_axi_rresp;
  wire [6:0] gpio_io_o;
  wire ip2intc_irpt;
  

  axi_gpio_0 dut (
    .s_axi_aclk(s_axi_aclk), .s_axi_aresetn(s_axi_aresetn),
    .s_axi_awaddr(s_axi_awaddr), .s_axi_awvalid(s_axi_awvalid), .s_axi_awready(s_axi_awready),
    .s_axi_wdata(s_axi_wdata), .s_axi_wstrb(s_axi_wstrb),
    .s_axi_wvalid(s_axi_wvalid), .s_axi_wready(s_axi_wready),
    .s_axi_bresp(s_axi_bresp), .s_axi_bvalid(s_axi_bvalid), .s_axi_bready(s_axi_bready),
    .s_axi_araddr(s_axi_araddr), .s_axi_arvalid(s_axi_arvalid), .s_axi_arready(s_axi_arready),
    .s_axi_rdata(s_axi_rdata), .s_axi_rresp(s_axi_rresp),
    .s_axi_rvalid(s_axi_rvalid), .s_axi_rready(s_axi_rready),
    .gpio_io_o(gpio_io_o),
    .ip2intc_irpt(ip2intc_irpt)
  );

  // 黄金模型：仅建模本例访问的寄存器，不复制 AMD RTL。
  // 依据 PG144 的地址映射、寄存器存在条件和读写定义。
  // model_tri/ier/gier 由复位配置和本测试台发出的已完成写事务更新。
  // 不读取 dut 内部层次信号；实际 RDATA 不参与预期值计算。
  logic [31:0] model_tri, model_ier, model_gier;
  logic [31:0] expected_rdata=0;
  int read_count=0, mismatch_count=0;
  function automatic logic [31:0] model_read(input logic [8:0] addr);
    case(addr)
      // 全输入模式的 GPIO_DATA 为引脚输入；本例不对输出模式的 DATA 读回作假设。
      9'h000: return 32'h0;
      9'h004: return model_tri & GPIO_MASK;
      // 本例第二通道未实现。PG144 Register Space 规定未实现寄存器读全零。
      // IS_DUAL 为存在性判断，不按实测错误值推导预期值。
      9'h008,9'h00C: begin
        if(IS_DUAL) $fatal(1,"Enabled GPIO2 is outside this reference model");
        return 32'h0;
      end
      9'h11C: return INTERRUPT_PRESENT ? model_gier : 32'h0;
      9'h128: return INTERRUPT_PRESENT ? model_ier : 32'h0;
      // 仅覆盖中断逻辑关闭时的IPISR；启用时的事件状态不在本模型范围。
      9'h120: begin
        if(INTERRUPT_PRESENT) $fatal(1,"Enabled IPISR is outside this reference model");
        return 32'h0;
      end
      default: begin $fatal(1,"Address outside this reference model");return 'x;end
    endcase
  endfunction

  // 单笔 AXI4-Lite 写：按 PG144 同时拉高 AWVALID/WVALID，分别保持到握手。
  // 数据与地址在下降沿驱动，在上升沿判断握手，避免与 IP 产生采样竞态。
  task automatic axi_write(input logic [8:0] addr,input logic [31:0] data,input int response_hold=0);
    bit aw_done,w_done;
    aw_done=0;w_done=0;
    @(negedge s_axi_aclk);
    s_axi_awaddr=addr;s_axi_wdata=data;s_axi_awvalid=1;s_axi_wvalid=1;
    for(int n=0;n<256;n++) begin
      @(posedge s_axi_aclk);
      if(s_axi_awvalid && s_axi_awready) aw_done=1;
      if(s_axi_wvalid && s_axi_wready) w_done=1;
      @(negedge s_axi_aclk);
      if(aw_done) s_axi_awvalid=0;
      if(w_done) s_axi_wvalid=0;
      if(aw_done && w_done) break;
    end
    if(!(aw_done && w_done)) $fatal(1,"AXI write request timeout");
    s_axi_bready=(response_hold==0);
    for(int n=0;n<256;n++) begin @(posedge s_axi_aclk);if(s_axi_bvalid===1'b1) break;end
    if(s_axi_bvalid!==1'b1 || s_axi_bresp!==2'b00) $fatal(1,"AXI write response failure");
    if(response_hold>0) begin
      $display("WRITE_AVAILABLE time_ns=%0d addr=%03h",$time,addr);
      repeat(response_hold) begin
        @(posedge s_axi_aclk);
        if(s_axi_bvalid!==1'b1 || s_axi_bresp!==2'b00)
          $fatal(1,"Write response changed under backpressure");
      end
      @(negedge s_axi_aclk);s_axi_bready=1;
      @(posedge s_axi_aclk);
      if(s_axi_bvalid!==1'b1 || s_axi_bresp!==2'b00) $fatal(1,"Write response handshake failure");
    end
    $display("WRITE time_ns=%0d addr=%03h data=%08h",$time,addr,data);
    // 仅在完整事务结束后更新软件参考状态。随后才会发起下一笔访问。
    case(addr)
      9'h004:model_tri=data & GPIO_MASK;
      9'h128:if(INTERRUPT_PRESENT) model_ier=data & 32'h1;
      9'h11C:if(INTERRUPT_PRESENT) model_gier=data & 32'h80000000;
      9'h000:begin end // 输出写入通过引脚核对，不用于目标地址的预期值。
      // PG144：未实现寄存器写入无效，不改变参考状态。
      9'h008,9'h00C:if(IS_DUAL) $fatal(1,"Enabled GPIO2 write outside model");
      9'h120:if(INTERRUPT_PRESENT) $fatal(1,"Enabled IPISR write outside model");
      default:$fatal(1,"Write outside this scenario");
    endcase
    @(negedge s_axi_aclk);s_axi_bready=0;
    repeat(TRANSACTION_GAP) @(negedge s_axi_aclk);
  endtask

  // 每次读都先由地址和参考状态计算预期值，再与读数据握手时的 IP 输出比较。
  // hold_cycles 用于合法地延后 RREADY；阻塞期间要求 RVALID/RDATA/RRESP 保持稳定。
  task automatic axi_read(input logic[8:0] addr,input int hold_cycles=0);
    logic [31:0] held_data;
    logic [1:0] held_resp;
    @(negedge s_axi_aclk);
    s_axi_araddr=addr;s_axi_arvalid=1;s_axi_rready=(hold_cycles==0);
    expected_rdata=model_read(addr);
    for(int n=0;n<256;n++) begin @(posedge s_axi_aclk);if(s_axi_arready===1'b1) break;end
    if(s_axi_arready!==1'b1) $fatal(1,"AXI read address timeout");
    $display("READ_REQUEST time_ns=%0d addr=%03h",$time,addr);
    @(negedge s_axi_aclk);s_axi_arvalid=0;
    for(int n=0;n<256;n++) begin @(posedge s_axi_aclk);if(s_axi_rvalid===1'b1) break;end
    if(s_axi_rvalid!==1'b1) $fatal(1,"AXI read response timeout");
    held_data=s_axi_rdata;held_resp=s_axi_rresp;
    if(hold_cycles>0) begin
      $display("READ_AVAILABLE time_ns=%0d addr=%03h actual=%08h",$time,addr,s_axi_rdata);
      repeat(hold_cycles) begin
        @(posedge s_axi_aclk);
        if(s_axi_rvalid!==1'b1 || s_axi_rdata!==held_data || s_axi_rresp!==held_resp)
          $fatal(1,"Read response changed under backpressure");
      end
      @(negedge s_axi_aclk);s_axi_rready=1;
      @(posedge s_axi_aclk);
    end
    if(s_axi_rvalid!==1'b1 || s_axi_rresp!==2'b00 || $isunknown(s_axi_rdata))
      $fatal(1,"Invalid read response");
    read_count++;
    $display("READ time_ns=%0d addr=%03h actual=%08h expected=%08h",$time,addr,s_axi_rdata,expected_rdata);
    if(s_axi_rdata!==expected_rdata) begin
      mismatch_count++;
      $display("DATA_MISMATCH addr=%03h",addr);
    end
    @(negedge s_axi_aclk);s_axi_rready=0;
    repeat(TRANSACTION_GAP) @(negedge s_axi_aclk);
  endtask

  // 仅在总线空闲时复位。参考状态由XCI复位配置恢复，不采样IP内部状态。
  task automatic reset_core();
    @(negedge s_axi_aclk);s_axi_aresetn=0;
    model_tri=TRI_DEFAULT & GPIO_MASK;model_ier=0;model_gier=0;
    $display("RESET_ASSERT time_ns=%0d",$time);
    repeat(RESET_CYCLES) @(negedge s_axi_aclk);s_axi_aresetn=1;
    $display("RESET_RELEASE time_ns=%0d",$time);
    repeat(RECOVERY_CYCLES) @(negedge s_axi_aclk);
  endtask

  initial begin
    $timeformat(-9,0," ns",10);reset_core();
    // 输出复位模式、稀疏数据、全零和全一均通过实际引脚核对。
    if(gpio_io_o!==7'h65) $fatal(1,"Output reset value mismatch");
    axi_write(9'h000,32'h25);
    if(gpio_io_o!==7'h25) $fatal(1,"GPIO output write failed");
    axi_write(9'h008,32'hFFFFFFFF);axi_write(9'h00C,32'h0);
    axi_read(9'h008);axi_read(9'h00C,5);
    axi_write(9'h000,32'h0);
    if(gpio_io_o!==7'h0) $fatal(1,"GPIO output write failed");
    axi_write(9'h00C,32'hFFFFFFFF);axi_write(9'h000,32'h7F);
    if(gpio_io_o!==7'h7F) $fatal(1,"GPIO output write failed");
    axi_read(9'h008);axi_read(9'h00C,19);
    repeat(8) @(negedge s_axi_aclk);
    $display("RESULT reads=%0d mismatches=%0d",read_count,mismatch_count);
    $display("CASE_COMPLETE");$finish;
  end
  initial begin #200000;$fatal(1,"Simulation watchdog timeout");end
endmodule

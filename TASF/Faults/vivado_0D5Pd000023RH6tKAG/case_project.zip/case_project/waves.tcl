# 显示 IP 外部端口及模型预期值，不展开模型中间状态。
if {[current_wave_config] eq ""} {create_wave_config}
add_wave /tb_gpio/s_axi_aclk
add_wave /tb_gpio/s_axi_aresetn
add_wave /tb_gpio/s_axi_awaddr
add_wave /tb_gpio/s_axi_awvalid
add_wave /tb_gpio/s_axi_awready
add_wave /tb_gpio/s_axi_wdata
add_wave /tb_gpio/s_axi_wstrb
add_wave /tb_gpio/s_axi_wvalid
add_wave /tb_gpio/s_axi_wready
add_wave /tb_gpio/s_axi_bresp
add_wave /tb_gpio/s_axi_bvalid
add_wave /tb_gpio/s_axi_bready
add_wave /tb_gpio/s_axi_araddr
add_wave /tb_gpio/s_axi_arvalid
add_wave /tb_gpio/s_axi_arready
add_wave /tb_gpio/s_axi_rdata
add_wave /tb_gpio/expected_rdata
add_wave /tb_gpio/s_axi_rresp
add_wave /tb_gpio/s_axi_rvalid
add_wave /tb_gpio/s_axi_rready
add_wave /tb_gpio/gpio_io_o
add_wave /tb_gpio/ip2intc_irpt
log_wave /tb_gpio/*
run all
puts "WAVE_READY"

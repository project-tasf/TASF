//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
//Date        : Fri Nov  6 13:57:29 2026
//Host        : DESKTOP-9V1R772 running 64-bit major release  (build 9200)
//Command     : generate_target ethernet_0_timer_syncer_wrapper.bd
//Design      : ethernet_0_timer_syncer_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module ethernet_0_timer_syncer_wrapper
   (core_rx0_period_0_0,
    core_tx0_period_0_0,
    rx_phy_clk_0_0,
    rx_phy_rst_0_0,
    rx_tod_ns_0_0,
    rx_tod_sec_0_0,
    s_axi_0_araddr,
    s_axi_0_arready,
    s_axi_0_arvalid,
    s_axi_0_awaddr,
    s_axi_0_awready,
    s_axi_0_awvalid,
    s_axi_0_bready,
    s_axi_0_bresp,
    s_axi_0_bvalid,
    s_axi_0_rdata,
    s_axi_0_rready,
    s_axi_0_rresp,
    s_axi_0_rvalid,
    s_axi_0_wdata,
    s_axi_0_wready,
    s_axi_0_wstrb,
    s_axi_0_wvalid,
    s_axi_aclk_0,
    s_axi_aresetn_0,
    sys_timer_1pps_out_0,
    tod_intr_0,
    ts_clk_0,
    ts_rst_0,
    tx_phy_clk_0_0,
    tx_phy_rst_0_0,
    tx_tod_ns_0_0,
    tx_tod_sec_0_0);
  input [63:0]core_rx0_period_0_0;
  input [63:0]core_tx0_period_0_0;
  input rx_phy_clk_0_0;
  input rx_phy_rst_0_0;
  output [31:0]rx_tod_ns_0_0;
  output [47:0]rx_tod_sec_0_0;
  input [31:0]s_axi_0_araddr;
  output s_axi_0_arready;
  input s_axi_0_arvalid;
  input [31:0]s_axi_0_awaddr;
  output s_axi_0_awready;
  input s_axi_0_awvalid;
  input s_axi_0_bready;
  output [1:0]s_axi_0_bresp;
  output s_axi_0_bvalid;
  output [31:0]s_axi_0_rdata;
  input s_axi_0_rready;
  output [1:0]s_axi_0_rresp;
  output s_axi_0_rvalid;
  input [31:0]s_axi_0_wdata;
  output s_axi_0_wready;
  input [3:0]s_axi_0_wstrb;
  input s_axi_0_wvalid;
  input s_axi_aclk_0;
  input s_axi_aresetn_0;
  output sys_timer_1pps_out_0;
  output tod_intr_0;
  input ts_clk_0;
  input ts_rst_0;
  input tx_phy_clk_0_0;
  input tx_phy_rst_0_0;
  output [31:0]tx_tod_ns_0_0;
  output [47:0]tx_tod_sec_0_0;

  wire [63:0]core_rx0_period_0_0;
  wire [63:0]core_tx0_period_0_0;
  wire rx_phy_clk_0_0;
  wire rx_phy_rst_0_0;
  wire [31:0]rx_tod_ns_0_0;
  wire [47:0]rx_tod_sec_0_0;
  wire [31:0]s_axi_0_araddr;
  wire s_axi_0_arready;
  wire s_axi_0_arvalid;
  wire [31:0]s_axi_0_awaddr;
  wire s_axi_0_awready;
  wire s_axi_0_awvalid;
  wire s_axi_0_bready;
  wire [1:0]s_axi_0_bresp;
  wire s_axi_0_bvalid;
  wire [31:0]s_axi_0_rdata;
  wire s_axi_0_rready;
  wire [1:0]s_axi_0_rresp;
  wire s_axi_0_rvalid;
  wire [31:0]s_axi_0_wdata;
  wire s_axi_0_wready;
  wire [3:0]s_axi_0_wstrb;
  wire s_axi_0_wvalid;
  wire s_axi_aclk_0;
  wire s_axi_aresetn_0;
  wire sys_timer_1pps_out_0;
  wire tod_intr_0;
  wire ts_clk_0;
  wire ts_rst_0;
  wire tx_phy_clk_0_0;
  wire tx_phy_rst_0_0;
  wire [31:0]tx_tod_ns_0_0;
  wire [47:0]tx_tod_sec_0_0;

  ethernet_0_timer_syncer ethernet_0_timer_syncer_i
       (.core_rx0_period_0_0(core_rx0_period_0_0),
        .core_tx0_period_0_0(core_tx0_period_0_0),
        .rx_phy_clk_0_0(rx_phy_clk_0_0),
        .rx_phy_rst_0_0(rx_phy_rst_0_0),
        .rx_tod_ns_0_0(rx_tod_ns_0_0),
        .rx_tod_sec_0_0(rx_tod_sec_0_0),
        .s_axi_0_araddr(s_axi_0_araddr),
        .s_axi_0_arready(s_axi_0_arready),
        .s_axi_0_arvalid(s_axi_0_arvalid),
        .s_axi_0_awaddr(s_axi_0_awaddr),
        .s_axi_0_awready(s_axi_0_awready),
        .s_axi_0_awvalid(s_axi_0_awvalid),
        .s_axi_0_bready(s_axi_0_bready),
        .s_axi_0_bresp(s_axi_0_bresp),
        .s_axi_0_bvalid(s_axi_0_bvalid),
        .s_axi_0_rdata(s_axi_0_rdata),
        .s_axi_0_rready(s_axi_0_rready),
        .s_axi_0_rresp(s_axi_0_rresp),
        .s_axi_0_rvalid(s_axi_0_rvalid),
        .s_axi_0_wdata(s_axi_0_wdata),
        .s_axi_0_wready(s_axi_0_wready),
        .s_axi_0_wstrb(s_axi_0_wstrb),
        .s_axi_0_wvalid(s_axi_0_wvalid),
        .s_axi_aclk_0(s_axi_aclk_0),
        .s_axi_aresetn_0(s_axi_aresetn_0),
        .sys_timer_1pps_out_0(sys_timer_1pps_out_0),
        .tod_intr_0(tod_intr_0),
        .ts_clk_0(ts_clk_0),
        .ts_rst_0(ts_rst_0),
        .tx_phy_clk_0_0(tx_phy_clk_0_0),
        .tx_phy_rst_0_0(tx_phy_rst_0_0),
        .tx_tod_ns_0_0(tx_tod_ns_0_0),
        .tx_tod_sec_0_0(tx_tod_sec_0_0));
endmodule

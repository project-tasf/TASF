
## ------------------------------------------------------------------------------
##   (c) Copyright 2020-2021 Advanced Micro Devices, Inc. All rights reserved.
## 
##   This file contains confidential and proprietary information
##   of Advanced Micro Devices, Inc. and is protected under U.S. and
##   international copyright and other intellectual property
##   laws.
## 
##   DISCLAIMER
##   This disclaimer is not a license and does not grant any
##   rights to the materials distributed herewith. Except as
##   otherwise provided in a valid license issued to you by
##   AMD, and to the maximum extent permitted by applicable
##   law: (1) THESE MATERIALS ARE MADE AVAILABLE \"AS IS\" AND
##   WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
##   AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
##   BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
##   INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
##   (2) AMD shall not be liable (whether in contract or tort,
##   including negligence, or under any other theory of
##   liability) for any loss or damage of any kind or nature
##   related to, arising under or in connection with these
##   materials, including for any direct, or any indirect,
##   special, incidental, or consequential loss or damage
##   (including loss of data, profits, goodwill, or any type of
##   loss or damage suffered as a result of any action brought
##   by a third party) even if such damage or loss was
##   reasonably foreseeable or AMD had been advised of the
##   possibility of the same.
## 
##   CRITICAL APPLICATIONS
##   AMD products are not designed or intended to be fail-
##   safe, or for use in any application requiring fail-safe
##   performance, such as life-support or safety devices or
##   systems, Class III medical devices, nuclear facilities,
##   applications related to the deployment of airbags, or any
##   other applications that could lead to death, personal
##   injury, or severe property or environmental damage
##   (individually and collectively, \"Critical
##   Applications\"). Customer assumes the sole risk and
##   liability of any use of AMD products in Critical
##   Applications, subject only to applicable laws and
##   regulations governing limitations on product liability.
## 
##   THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
##   PART OF THIS FILE AT ALL TIMES.
##
## 
##
##       Owner:          
##       Revision:       $Id: $
##                       $Author: $
##                       $DateTime: $
##                       $Change: $
##       Description:
##
##////////////////////////////////////////////////////////////////////////////
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# XXV_ETHERNET example design-level XDC file
# ----------------------------------------------------------------------------------------------------------------------
## init_clk should be lesser or equal to reference clock.
### Transceiver Reference Clock Placement
### Transceivers should be adjacent to allow timing constraints to be met easily. 
### Full details of available transceiver locations can be found
### in the appropriate transceiver User Guide, or use the Transceiver Wizard.
create_clock -period 12.000 [get_ports dclk]
set_property IOSTANDARD LVCMOS18 [get_ports dclk]
create_clock -period 6.400 [get_ports gt_refclk_p]


### These are sample constraints, please use correct constraints for your device 
### update the gt_refclk pin location accordingly and un-comment the below two lines 
  #set_property PACKAGE_PIN AK38 [get_ports gt_refclk_p]
  #set_property PACKAGE_PIN AK39 [get_ports gt_refclk_n]

###Board constraints to be added here
### Below XDC constraints are for VCU108 board with xcvu095-ffva2104-2-e-es2 device
### Change these constraints as per your board and device
#### Push Buttons
###set_property PACKAGE_PIN D9 [get_ports sys_reset]
set_property IOSTANDARD LVCMOS18 [get_ports sys_reset]

#set_property LOC A10 [get_ports restart_tx_rx_0]
set_property IOSTANDARD LVCMOS18 [get_ports restart_tx_rx_0]

### LEDs
#set_property PACKAGE_PIN AT32 [get_ports rx_gt_locked_led_0]
set_property IOSTANDARD LVCMOS18 [get_ports rx_gt_locked_led_0]
##
#set_property PACKAGE_PIN AV34 [get_ports rx_block_lock_led_0]
set_property IOSTANDARD LVCMOS18 [get_ports rx_block_lock_led_0]
##
#set_property PACKAGE_PIN AY30 [get_ports completion_status[0]]
set_property IOSTANDARD LVCMOS18 [get_ports completion_status[0]]
##
#set_property PACKAGE_PIN BB32 [get_ports completion_status[1]]
set_property IOSTANDARD LVCMOS18 [get_ports completion_status[1]]
##
#set_property PACKAGE_PIN BF32 [get_ports completion_status[2]]
set_property IOSTANDARD LVCMOS18 [get_ports completion_status[2]]
##
#set_property PACKAGE_PIN AV36 [get_ports completion_status[3]]
set_property IOSTANDARD LVCMOS18 [get_ports completion_status[3]]
##
#set_property PACKAGE_PIN AY35 [get_ports completion_status[4]]
set_property IOSTANDARD LVCMOS18 [get_ports completion_status[4]]







### Any other Constraints  
set_false_path -to [get_cells -hierarchical -filter {NAME =~ */i_*_axi_if_top/*/i_*_syncer/*meta_reg*}]
set_false_path -to [get_cells -hierarchical -filter {NAME =~ */i_*_SYNC*/*stretch_reg*}]

set_false_path -to [get_cells -hierarchical -filter {NAME=~ */i*syncer/*d2_cdc_to*}]

set_false_path -to [get_pins i*core_support/i*sharedlogic_wrapper/i*reset_wrapper_*/*/*_cdc_to_reg*/D]

set_false_path -to [get_cells -hierarchical -filter {NAME =~ */*ptp_port_timer/*ns_meta_reg*}] -quiet













set_false_path -to [get_pins i*core_support/i*sharedlogic_wrapper/i*reset_wrapper_*/*/*_cdc_to_reg*/D]

set_max_delay  12.000 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */pktgen_enable_int_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */*_sync_pkt_gen_enable/s_out_d2_cdc_to_reg*}] -filter { name =~ *D } ] -quiet
set_max_delay  12.000 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */i_RX_WD_ALIGN/align_status_reg[*]*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */s_out_d2_cdc_to_reg*}] -filter { name =~ *D } ] -quiet
set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */rx_errors_int_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */s_out_d2_cdc_to_reg[*]*}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet


set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */mode_switch_reg*}] -filter { name =~ *C } ] 12.000 -datapath_only -quiet
set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */pipe_reg*}] -filter { name =~ *C } ] 2.5 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */s_out_d4_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */s_out_d2_cdc_to_reg*}] -filter { name =~ *D } ]  12.000 -datapath_only -quiet
set_max_delay 6.4 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */rst_in_out_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */s_out_d2_cdc_to_reg*}] -filter { name =~ *D } ] -quiet
set_max_delay 6.4 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */rx_reset_done_async_r_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */s_out_d2_cdc_to_reg*}] -filter { name =~ *D } ] -quiet

set_max_delay  12.000 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_rsfec_enable_r_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */gt*_channel_gen.gen_gt*_channel_inst[*].GT*_CHANNEL_PRIM_INST*}] -filter { name =~ *RXGEARBOXSLIP } ] -quiet

set_max_delay 12.000 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_*x_opcode_*}] -filter { name =~ *C } ]  -quiet




##


#create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */s_out_d2_cdc_to_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The reset signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */rx_reset_done_async_r*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */s_out_d2_cdc_to_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAFFIC_GENERATOR/i_*_PKT_CHK/rx_block_lock_led_*d_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-2} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAFFIC_GENERATOR/i_*_PKT_CHK/rx_block_lock_led_*d_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_DELETE_FCS/*_d*_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAFFIC_GENERATOR/*_reg*}] -filter {name =~ *}]

#create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAF_CHK*/rx_block_lock_led_*d_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAF_CHK*/rx_block_lock_led_*d_reg*}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-2} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAF_CHK*/rx_block_lock_led_*d_reg*}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "The align status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
-to [get_pins -of [get_cells -hier -filter {name =~ */i_*_TRAF_CHK*/*_reg*}] -filter {name =~ *}]





create_clock -period 8.000 [get_ports ts_clk]
set_property IOSTANDARD LVCMOS18 [get_ports ts_clk]
set_property IOSTANDARD LVCMOS18 [get_ports ptp_result_0]

set_max_delay  12.000 -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_ptp_transpclk_mode_*}] -filter { name =~ *C } ] -quiet

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is level signal in reset path, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_ptp_transpclk_mode_*}] -filter { name =~ *C } ]

#create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is level signal in reset path, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_ptp_transpclk_mode_*}] -filter { name =~ *C } ]

#create_waiver -type CDC -id {CDC-2} -user "xxv_ethernet" -desc "This is level signal in reset path, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_ptp_transpclk_mode_*}] -filter { name =~ *C } ]

#create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is level signal in reset path, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/ctl_ptp_transpclk_mode_*}] -filter { name =~ *C } ]
## TIMER SYNCER
set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_ptp_sys_timer/sys_tod_*_reg[*]*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet
  
set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_pif_registers/rx_sys_offset_out_*_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/rx_ns_meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet
                            
set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */inst/*_period_*_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */inst/*_period_*_sync_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/req_event_reg}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/i_REQ/meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/ready_clkin_reg}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/i_READY/meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */inst/*_period_*_sync_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_rx_period/latched_inputs_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/ack_event_reg}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*_period/i_ACK/meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */tx_period_*_sync_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_tx_period/latched_inputs_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/tx_period_meta_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */base_timer_tx/gen_tod_low_tod_cnt.low_tod_tod_count_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/base_timer_*x/low_period_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/base_timer_*x/gen_tod_low_tod_cnt.low_tod_tod_count_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/rx_period_meta_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */base_timer_rx/gen_tod_low_tod_cnt.low_tod_tod_count*}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/base_timer_rx/no_mrmac_mode_low_per_count.low_period_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */base_timer_rx/gen_tod_low_tod_cnt.low_tod_tod_count*}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet
##set_alse_path -to [get_cells -hier -filter {name=~ */ptp_1588_timer_syncer_*/inst/*_timer_syncer_ptp_1588_timer_syncer_*_core_top/*_ptp_port_timer/*_meta_reg*}]

#set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_*_timer/base_timer_*/gen_tod_low_tod_cnt.*}] -filter { name =~ *C } ]\
#-to [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_*_timer/base_timer_*/gen_tod_low_tod_cnt.*}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

#set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i*_ptp_port_timer/base_timer_*x/gen_tod_low_tod_cnt.*}] -filter { name =~ *C } ] 12.000 -dat#apath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_ptp_sys_timer/gen_no_timer_only.sys_tod_ns_reg[*]*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_ptp_sys_timer/gen_no_timer_only.sys_tod_sec_*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_syncer_bus_*x_period_*_clk/busout_reg[*]}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*x_period/latched_inputs_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */i_syncer_bus_*x_period_*_clk/*_event_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */i*_syncer_bus_*x_period*/*/meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */*_syncer_bus_*x_period/ready_clkin_reg*}] -filter { name =~ *C } ]\
-to [get_pins -of [get_cells -hier -filter { name =~ */*_syncer_bus_*x_period*/i_R*/meta_reg[*]}] -filter { name =~ *D } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */*axi4_lite_rd_wr_if/axi_*}] -filter { name =~ *C } ] 12.000 -datapath_only -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */inst/*_axi_if_top/*_axi_slave_*_ipif/axi_*}] -filter { name =~ *C } ] 12.000 -datapath_only -quiet

create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside teh timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_ports sys_reset]\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_syncer*_ts_clk/busout_reg[*]}] -filter {name =~ *R}]

create_waiver -type CDC -id {CDC-2} -user "xxv_ethernet" -desc "This is inside teh timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_ports sys_reset]\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_syncer*_ts_clk/busout_reg[*]}] -filter {name =~ *R}]

create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*syncer_bus_*_period/latched_inputs_reg[*]}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_syncer_bus_*_period/busout_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter {name =~ *C}]
#-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i_ptp_sys_timer/sys_tod_*_reg[*]*}] -filter {name =~ *C}]
#-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/sys_tod_*_out_i_reg[*]}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i_ptp_sys_timer/gen_timer_only.sys_tod_*_reg*}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/xpm_cdc_sys_tod_*_syncer*/syncstages_ff_reg*}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/xpm_cdc_sys_tod_*_syncer*/syncstages_ff_reg*}] -filter {name =~ *C}] 

create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/xpm_cdc_sys_tod_*_syncer*/syncstages_ff_reg*}] -filter {name =~ *C}] 

create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This is inside the timer syncer, safe to ignore so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/*/inst/bit*_sample_*/source_data_in_reg*}] -filter {name =~ *C}] 

create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The stat_rx_block_lock signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i_ptp_sys_timer/update_port_timer_reg}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_timer_correct/i_update_timer_dual_phase_syncer/i_syncer_level*/meta_reg[*]}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-6} -user "xxv_ethernet" -desc "ASYNC reg is not required for this syncer, so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ i_*_pkt_gen_mon_*/*_int_reg[*]}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */*_syncer/s_out_d2_cdc_to_reg[*]}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-15} -user "xxv_ethernet" -desc "This is inside the syncer module, so can be waived" -tags "11999"\
-to [get_pins -of [get_cells -hier -filter {name =~ */inst/i_*_core_top/i*_syncer_bus_*_period/latched_inputs_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-15} -user "xxv_ethernet" -desc "This is inside the syncer module, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_axi_if_top/i_pif_registers/*x_sys_offset_out_*_reg[*]}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */i*ptp_port_timer/*_ns_meta_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-15} -user "xxv_ethernet" -desc "This is inside the syncer module, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */inst/*_period_*_h_reg[*]}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~ */inst/*_period_*sync_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is inside the syncer module, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_pif_registers/*x_sys_offset_out_*_reg[*]}] -filter {name =~ *C}]
#-to [get_pins -of [get_cells -hier -filter {name =~ */i*_ptp_port_timer/*x_ns_meta_reg[*]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-2} -user "xxv_ethernet" -desc "This is inside the syncer module, so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_pif_registers/*x_sys_offset_out_*_reg[*]}] -filter {name =~ *C}]
#-to [get_pins -of [get_cells -hier -filter {name =~ */i*_ptp_port_timer/*x_ns_meta_reg[*]}] -filter {name =~ *D}]

set_max_delay 6.4 -datapath_only -from [get_pins -of [get_cells -hier -filter {name =~ */*_cdc_sync_gt_*x_resetdone*/s_out_d4_reg*}] -filter {name =~ *C}] -quiet

#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "The CDC-1 warning is waived as it is a level signaln reset path. This is safe to ignore" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */*_cdc_sync_gt_*x_resetdone*/s_out_d4_reg*}] -filter {name =~ *C}]

#create_waiver -type CDC -id {CDC-13} -user "xxv_ethernet" -desc "This CDC-13 warning is waived as it isa level signaln reset path. This is safe to ignore" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */*_cdc_sync_gt_*x_resetdone*/s_out_d4_reg*}] -filter {name =~ *C}]

#create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The reset signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */*_cdc_sync_gt_*x_resetdone*/s_out_d4_reg*}] -filter {name =~ *C}]


set_max_delay -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */*_axi_if_top/i_pif_registers/ctl_rsfec_enable_r_reg*}] -filter { name =~ *C }] 12.000 -quiet

set_max_delay -datapath_only -from [get_pins -of [get_cells -hier -filter { name =~ */*_axi_if_top/i_pif_registers/ctl_*x_max_packet_len_out_reg*}] -filter { name =~ *C }] 12.000 -quiet

set_max_delay -from [get_pins -of [get_cells -hier -filter { name =~ */inst/*x_*bit_gt_pipeline_serdes*/data_out_*d*}] -filter { name =~ *C } ] 12.000 -datapath_only -quiet

#
#create_waiver -type CDC -id {CDC-1} -user "xxv_ethernet" -desc "This CDC-1 warning is waived as it is a static signal, This is safe to ignore" -tags "1240022"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */i_pif_registers/i_reg_STAT_STATUS_REG1_clear_syncer/dataout_reg_reg[0]}] -filter {name =~ *C}] 
#-to [get_pins -of [get_cells -hier -filter {name =~  */i_pif_registers/stat_rx_fifo_error_lh_r_reg[0]}] -filter {name =~ *D}]

#create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "The CDC-10 warning is waived as  it is Part of synchronizer. This is safe to ignore" -tags "1240022"\
#-from [get_pins -of [get_cells -hier -filter {name =~ */*_fifo_rst_inst/gen_rst_ic.wr_rst_busy_ic_reg}] -filter {name =~ *C}]\
#-to [get_pins -of [get_cells -hier -filter {name =~  */*_syncer_level/meta_reg[0]}] -filter {name =~ *D}]
#

create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The align_status signal is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */*_LANE/i_RX_WD_ALIGN/align_status_reg*}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */s_out_d2_cdc_to_reg}] -filter {name =~ *D}]

create_waiver -type CDC -id {CDC-11} -user "xxv_ethernet" -desc "The reset signal_1 is synced with different syncers where fan-out is expected and so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter {name =~ */rx_reset_done_async_r*}] -filter {name =~ *C}]\
-to [get_pins -of [get_cells -hier -filter {name =~ */s_out_d2_cdc_to_reg*}] -filter {name =~ *D}]




create_waiver -type CDC -id {CDC-10} -user "xxv_ethernet" -desc "This is level signal in reset path, so can be waived" -tags "11999"\
-from [get_pins -of [get_cells -hier -filter { name =~ *ptp_axi4_lite_user_if*/*_ptp_axi4_lite_rd_wr_if/axi_*_reg*}] -filter { name =~ *C } ]



set_clock_groups -group [get_clocks -of_objects [get_ports dclk] ] -asynchronous
set_clock_groups -group [get_clocks -of_objects [get_ports ts_clk] ] -asynchronous

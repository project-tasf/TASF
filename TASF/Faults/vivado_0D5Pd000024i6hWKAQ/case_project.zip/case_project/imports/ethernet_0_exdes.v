// ------------------------------------------------------------------------------
//   (c) Copyright 2020-2021 Advanced Micro Devices, Inc. All rights reserved.
// 
//   This file contains confidential and proprietary information
//   of Advanced Micro Devices, Inc. and is protected under U.S. and
//   international copyright and other intellectual property
//   laws.
// 
//   DISCLAIMER
//   This disclaimer is not a license and does not grant any
//   rights to the materials distributed herewith. Except as
//   otherwise provided in a valid license issued to you by
//   AMD, and to the maximum extent permitted by applicable
//   law: (1) THESE MATERIALS ARE MADE AVAILABLE \"AS IS\" AND
//   WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
//   AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//   BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//   INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//   (2) AMD shall not be liable (whether in contract or tort,
//   including negligence, or under any other theory of
//   liability) for any loss or damage of any kind or nature
//   related to, arising under or in connection with these
//   materials, including for any direct, or any indirect,
//   special, incidental, or consequential loss or damage
//   (including loss of data, profits, goodwill, or any type of
//   loss or damage suffered as a result of any action brought
//   by a third party) even if such damage or loss was
//   reasonably foreseeable or AMD had been advised of the
//   possibility of the same.
// 
//   CRITICAL APPLICATIONS
//   AMD products are not designed or intended to be fail-
//   safe, or for use in any application requiring fail-safe
//   performance, such as life-support or safety devices or
//   systems, Class III medical devices, nuclear facilities,
//   applications related to the deployment of airbags, or any
//   other applications that could lead to death, personal
//   injury, or severe property or environmental damage
//   (individually and collectively, \"Critical
//   Applications\"). Customer assumes the sole risk and
//   liability of any use of AMD products in Critical
//   Applications, subject only to applicable laws and
//   regulations governing limitations on product liability.
// 
//   THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//   PART OF THIS FILE AT ALL TIMES.
//
// 
//
//       Owner:          
//       Revision:       $Id: $
//                       $Author: $
//                       $DateTime: $
//                       $Change: $
//       Description:
//
// 
////------------------------------------------------------------------------------


`timescale 1fs/1fs

(* DowngradeIPIdentifiedWarnings="yes" *)
module ethernet_0_exdes
(
    input  wire gt_rxp_in_0,
    input  wire gt_rxn_in_0,
    output wire gt_txp_out_0,
    output wire gt_txn_out_0,
    input       ts_clk,
    output wire ptp_result_0,
    input  wire restart_tx_rx_0,
    input  wire send_continous_pkts_0,   // This port can be used to send continous packets 
    output wire rx_gt_locked_led_0,     // Indicates GT LOCK
    output wire rx_block_lock_led_0,    // Indicates Core Block Lock
    output wire [4:0] completion_status,
    output wire stat_reg_compare, 
    input             sys_reset,
    input             gt_refclk_p,
    input             gt_refclk_n,
    input             dclk
);

  parameter PKT_NUM         = 20;    //// Many Internal Counters are based on PKT_NUM = 20

//// AXI_0 interface ports
  wire s_axi_aclk_0;
  wire s_axi_aresetn_0;
  wire [31:0] s_axi_awaddr_0;
  wire s_axi_awvalid_0;
  wire s_axi_awready_0;
  wire [31:0] s_axi_wdata_0;
  wire [3:0] s_axi_wstrb_0;
  wire s_axi_wvalid_0;
  wire s_axi_wready_0;
  wire [1:0] s_axi_bresp_0;
  wire s_axi_bvalid_0;
  wire s_axi_bready_0;
  wire [31:0] s_axi_araddr_0;
  wire s_axi_arvalid_0;
  wire s_axi_arready_0;
  wire [31:0] s_axi_rdata_0;
  wire [1:0] s_axi_rresp_0;
  wire s_axi_rvalid_0;
  wire s_axi_rready_0;
  wire pm_tick_0;
  wire stat_reg_compare_0;
  wire gt_loopback_out_0;
  wire  block_lock_led_0;
  
  
////GT Transceiver debug interface signals
  wire [16:0] gt_dmonitorout_0;
  wire [0:0] gt_eyescandataerror_0;
  wire [0:0] gt_eyescanreset_0;
  wire [0:0] gt_eyescantrigger_0;
  wire [15:0] gt_pcsrsvdin_0;
  wire [0:0] gt_rxbufreset_0;
  wire [2:0] gt_rxbufstatus_0;
  wire [0:0] gt_rxcdrhold_0;
  wire [0:0] gt_rxcommadeten_0;
  wire [0:0] gt_rxdfeagchold_0;
  wire [0:0] gt_rxdfelpmreset_0;
  wire [0:0] gt_rxlatclk_0;
  wire [0:0] gt_rxlpmen_0;
  wire [0:0] gt_rxpcsreset_0;
  wire [0:0] gt_rxpmareset_0;
  wire [0:0] gt_rxpolarity_0;
  wire [0:0] gt_rxprbscntreset_0;
  wire [0:0] gt_rxprbserr_0;
  wire [0:0] gt_rxprbslocked_0;
  wire [0:0] gt_txresetdone_0;
  wire [3:0] gt_rxprbssel_0;
  wire [2:0] gt_rxrate_0;
  wire [0:0] gt_rxslide_in_0;
  wire [1:0] gt_rxstartofseq_0;
  wire [1:0] gt_txbufstatus_0;
  wire [0:0] gt_txinhibit_0;
  wire [0:0] gt_txlatclk_0;
  wire [6:0] gt_txmaincursor_0;
  wire [0:0] gt_txpcsreset_0;
  wire [0:0] gt_txpmareset_0;
  wire [0:0] gt_txpolarity_0;
  wire [4:0] gt_txpostcursor_0;
  wire [0:0] gt_txprbsforceerr_0;
  wire [0:0] gt_txelecidle_0;
  wire [3:0] gt_txprbssel_0;
  wire [4:0] gt_txprecursor_0;
  wire [4:0] gt_txdiffctrl_0;

////GT DRP interface signals
  wire [15:0] gt_drpdo_0;
  wire [0:0] gt_drprdy_0;
  wire [0:0] gt_drpen_0;
  wire [0:0] gt_drpwe_0;
  wire [9:0] gt_drpaddr_0;
  wire [15:0] gt_drpdi_0;
  wire rx_core_clk_0;
  wire rx_clk_out_0;
  wire tx_clk_out_0;
  //assign rx_core_clk_0 = tx_clk_out_0;
  assign rx_core_clk_0 = rx_clk_out_0;

//// RX_0 Signals
  wire rx_reset_0;
  wire user_rx_reset_0;
  wire rxrecclkout_0;

//// RX_0 User Interface Signals
  wire rx_axis_tvalid_0;
  wire [63:0] rx_axis_tdata_0;
  wire rx_axis_tlast_0;
  wire [7:0] rx_axis_tkeep_0;
  wire rx_axis_tuser_0;
  wire [55:0] rx_preambleout_0;

//// RX_0 Control Signals




//// RX_0 Stats Signals
  wire stat_rx_block_lock_0;
  wire stat_rx_framing_err_valid_0;
  wire stat_rx_framing_err_0;
  wire stat_rx_hi_ber_0;
  wire stat_rx_valid_ctrl_code_0;
  wire stat_rx_bad_code_0;
  wire [1:0] stat_rx_total_packets_0;
  wire stat_rx_total_good_packets_0;
  wire [3:0] stat_rx_total_bytes_0;
  wire [13:0] stat_rx_total_good_bytes_0;
  wire stat_rx_packet_small_0;
  wire stat_rx_jabber_0;
  wire stat_rx_packet_large_0;
  wire stat_rx_oversize_0;
  wire stat_rx_undersize_0;
  wire stat_rx_toolong_0;
  wire stat_rx_fragment_0;
  wire stat_rx_packet_64_bytes_0;
  wire stat_rx_packet_65_127_bytes_0;
  wire stat_rx_packet_128_255_bytes_0;
  wire stat_rx_packet_256_511_bytes_0;
  wire stat_rx_packet_512_1023_bytes_0;
  wire stat_rx_packet_1024_1518_bytes_0;
  wire stat_rx_packet_1519_1522_bytes_0;
  wire stat_rx_packet_1523_1548_bytes_0;
  wire [1:0] stat_rx_bad_fcs_0;
  wire stat_rx_packet_bad_fcs_0;
  wire [1:0] stat_rx_stomped_fcs_0;
  wire stat_rx_packet_1549_2047_bytes_0;
  wire stat_rx_packet_2048_4095_bytes_0;
  wire stat_rx_packet_4096_8191_bytes_0;
  wire stat_rx_packet_8192_9215_bytes_0;
  wire stat_rx_unicast_0;
  wire stat_rx_multicast_0;
  wire stat_rx_broadcast_0;
  wire stat_rx_vlan_0;
  wire stat_rx_inrangeerr_0;
  wire stat_rx_bad_preamble_0;
  wire stat_rx_bad_sfd_0;
  wire stat_rx_got_signal_os_0;
  wire stat_rx_test_pattern_mismatch_0;
  wire stat_rx_truncated_0;
  wire stat_rx_local_fault_0;
  wire stat_rx_remote_fault_0;
  wire stat_rx_internal_local_fault_0;
  wire stat_rx_received_local_fault_0;
   wire stat_rx_status_0;
  wire [1:0] tx_ptp_1588op_in_0;
  wire [15:0] tx_ptp_tag_field_in_0;
  wire tx_ptp_tstamp_valid_out_0;
  wire [15:0] tx_ptp_tstamp_tag_out_0;
  wire [79:0] tx_ptp_tstamp_out_0;
  wire [79:0] rx_ptp_tstamp_out_0;
  wire rx_ptp_tstamp_valid_out_0;
 
  wire tx_ptp_upd_chksum_in_0;
  wire [15:0] tx_ptp_tstamp_offset_in_0;
  wire [15:0] tx_ptp_chksum_offset_in_0;
  wire [79:0] ctl_rx_systemtimerin_0;
  wire [79:0] ctl_tx_systemtimerin_0;
  wire stat_tx_ptp_fifo_read_error_0;
  wire stat_tx_ptp_fifo_write_error_0;
//// TX_0 Signals
  wire tx_reset_0;
  wire user_tx_reset_0;

//// TX_0 User Interface Signals
  wire tx_axis_tready_0;
  wire tx_axis_tvalid_0;
  wire [63:0] tx_axis_tdata_0;
  wire tx_axis_tlast_0;
  wire [7:0] tx_axis_tkeep_0;
  wire tx_axis_tuser_0;
  wire tx_unfout_0;
  wire [55:0] tx_preamblein_0;
//// TX_0 Control Signals
  wire ctl_tx_send_lfi_0;
  wire ctl_tx_send_rfi_0;
  wire ctl_tx_send_idle_0;

  wire [8:0] ctl_tx_pause_req_0;
  wire ctl_tx_resend_pause_0;

//// TX_0 Stats Signals
  wire stat_tx_total_packets_0;
  wire [3:0] stat_tx_total_bytes_0;
  wire stat_tx_total_good_packets_0;
  wire [13:0] stat_tx_total_good_bytes_0;
  wire stat_tx_packet_64_bytes_0;
  wire stat_tx_packet_65_127_bytes_0;
  wire stat_tx_packet_128_255_bytes_0;
  wire stat_tx_packet_256_511_bytes_0;
  wire stat_tx_packet_512_1023_bytes_0;
  wire stat_tx_packet_1024_1518_bytes_0;
  wire stat_tx_packet_1519_1522_bytes_0;
  wire stat_tx_packet_1523_1548_bytes_0;
  wire stat_tx_packet_small_0;
  wire stat_tx_packet_large_0;
  wire stat_tx_packet_1549_2047_bytes_0;
  wire stat_tx_packet_2048_4095_bytes_0;
  wire stat_tx_packet_4096_8191_bytes_0;
  wire stat_tx_packet_8192_9215_bytes_0;
  wire stat_tx_unicast_0;
  wire stat_tx_multicast_0;
  wire stat_tx_broadcast_0;
  wire stat_tx_vlan_0;
  wire stat_tx_bad_fcs_0;
  wire stat_tx_frame_error_0;
  wire stat_tx_local_fault_0;

  wire stat_tx_pause_0;
  wire stat_tx_user_pause_0;
  wire [8:0] stat_tx_pause_valid_0;



   wire gtpowergood_out_0;
   wire [2:0] txoutclksel_in_0;
   wire [2:0] rxoutclksel_in_0;

   assign txoutclksel_in_0 = 3'b101;    // this value should not be changed as per gtwizard 
   assign rxoutclksel_in_0 = 3'b101;    // this value should not be changed as per gtwizard
   assign rx_block_lock_led_0 = block_lock_led_0 & stat_rx_status_0;
  wire [31:0] user_reg0_0;
   wire qpllreset_in_0;
   assign qpllreset_in_0 = 1'b0;         // Changing qpllreset_in_0 value may impact or disturb other cores in case of multicore
                                         // User should take care of this while changing.
  
  wire  [4:0 ]completion_status_0;
  wire  gt_refclk_out;






  wire [31:0]     s_axi_awaddr_ptp_0;
  wire            s_axi_awvalid_ptp_0;
  wire            s_axi_awready_ptp_0;
  wire [31:0]     s_axi_wdata_ptp_0;
  wire [3:0]      s_axi_wstrb_ptp_0;
  wire            s_axi_wvalid_ptp_0;
  wire            s_axi_wready_ptp_0;
  wire [1:0]      s_axi_bresp_ptp_0;
  wire            s_axi_bvalid_ptp_0;
  wire            s_axi_bready_ptp_0;
  wire [31:0]     s_axi_araddr_ptp_0;
  wire            s_axi_arvalid_ptp_0;
  wire            s_axi_arready_ptp_0;
  wire [31:0]     s_axi_rdata_ptp_0;
  wire [1:0]      s_axi_rresp_ptp_0;
  wire            s_axi_rvalid_ptp_0;
  wire            s_axi_rready_ptp_0;
  wire            sys_timer_1pps_out_0;
  wire            tod_intr_0;
  // Port clock and reset inputs
  wire            tx_phy_clk_0;
  wire            rx_phy_clk_0;
  wire            tx_phy_rst_0;
  wire            rx_phy_rst_0;
  wire [63:0]     tx_period_ns_0;
  wire [63:0]     rx_period_ns_0;

  
  // Synced Port timer ToD field outputs  
  wire  [48-1:0]  tx_tod_sec_0;
  wire  [32-1:0]  tx_tod_ns_0;
  wire  [48-1:0]  rx_tod_sec_0;
  wire  [32-1:0]  rx_tod_ns_0;
  assign tx_phy_clk_0 = tx_clk_out_0;
  
  assign rx_phy_clk_0 = rx_clk_out_0; 
  assign tx_phy_rst_0 = user_tx_reset_0; 
  assign rx_phy_rst_0 = user_rx_reset_0; 
  assign ctl_rx_systemtimerin_0 = {rx_tod_sec_0,rx_tod_ns_0};
  assign ctl_tx_systemtimerin_0 = {tx_tod_sec_0,tx_tod_ns_0};
  assign ptp_result_0 = (rx_ptp_tstamp_out_0 > tx_ptp_tstamp_out_0) ? 1'b1 : 1'b0;

ethernet_0_ptp_axi4_lite_user_if i_ethernet_0_ptp_axi4_lite_user_if_0 (
 .s_axi_aclk (dclk),
 .s_axi_sreset (sys_reset),
 .stat_rx_aligned (stat_rx_block_lock_0),
  
 .s_axi_awaddr (s_axi_awaddr_ptp_0),
 .s_axi_awvalid (s_axi_awvalid_ptp_0),
 .s_axi_awready (s_axi_awready_ptp_0),
 .s_axi_wdata (s_axi_wdata_ptp_0),
 .s_axi_wstrb (s_axi_wstrb_ptp_0),
 .s_axi_wvalid (s_axi_wvalid_ptp_0),
 .s_axi_wready (s_axi_wready_ptp_0),
 .s_axi_bresp (s_axi_bresp_ptp_0),
 .s_axi_bvalid (s_axi_bvalid_ptp_0),
 .s_axi_bready (s_axi_bready_ptp_0),
 .s_axi_araddr (s_axi_araddr_ptp_0),
 .s_axi_arvalid (s_axi_arvalid_ptp_0),
 .s_axi_arready (s_axi_arready_ptp_0),
 .s_axi_rdata (s_axi_rdata_ptp_0),
 .s_axi_rresp (s_axi_rresp_ptp_0),
 .s_axi_rvalid (s_axi_rvalid_ptp_0),
 .s_axi_rready (s_axi_rready_ptp_0)

); 

ethernet_0_timer_syncer_wrapper i_ethernet_0_new_timer_syncer_0 (
  .ts_clk_0(ts_clk),
  .ts_rst_0(sys_reset),
  .core_tx0_period_0_0(tx_period_ns_0),
  .core_rx0_period_0_0(rx_period_ns_0),
  .tx_phy_clk_0_0(tx_phy_clk_0),
  .rx_phy_clk_0_0(rx_phy_clk_0),
  .tx_phy_rst_0_0(tx_phy_rst_0),
  .rx_phy_rst_0_0(rx_phy_rst_0),
  .tx_tod_sec_0_0(tx_tod_sec_0),
  .tx_tod_ns_0_0(tx_tod_ns_0),
  .rx_tod_sec_0_0(rx_tod_sec_0),
  .rx_tod_ns_0_0(rx_tod_ns_0),
  .sys_timer_1pps_out_0(sys_timer_1pps_out_0),
  .tod_intr_0(tod_intr_0),
  .s_axi_aclk_0(dclk),
  .s_axi_aresetn_0(~sys_reset),
  .s_axi_0_awaddr({20'd0,s_axi_awaddr_ptp_0[11:0]}),
  .s_axi_0_awvalid(s_axi_awvalid_ptp_0),
  .s_axi_0_awready(s_axi_awready_ptp_0),
  .s_axi_0_wdata(s_axi_wdata_ptp_0),
  .s_axi_0_wstrb(s_axi_wstrb_ptp_0),
  .s_axi_0_wvalid(s_axi_wvalid_ptp_0),
  .s_axi_0_wready(s_axi_wready_ptp_0),
  .s_axi_0_bresp(s_axi_bresp_ptp_0),
  .s_axi_0_bvalid(s_axi_bvalid_ptp_0),
  .s_axi_0_bready(s_axi_bready_ptp_0),
  .s_axi_0_araddr({20'd0,s_axi_araddr_ptp_0[11:0]}),
  .s_axi_0_arvalid(s_axi_arvalid_ptp_0),
  .s_axi_0_arready(s_axi_arready_ptp_0),
  .s_axi_0_rdata(s_axi_rdata_ptp_0),
  .s_axi_0_rresp(s_axi_rresp_ptp_0),
  .s_axi_0_rvalid(s_axi_rvalid_ptp_0),
  .s_axi_0_rready(s_axi_rready_ptp_0)
);

  
ethernet_0_core_support i_ethernet_0_core_support
(

    .gt_rxp_in_0 (gt_rxp_in_0),
    .gt_rxn_in_0 (gt_rxn_in_0),
    .gt_txp_out_0 (gt_txp_out_0),
    .gt_txn_out_0 (gt_txn_out_0),
    .tx_clk_out_0 (tx_clk_out_0),
    .rx_core_clk_0 (rx_core_clk_0),
    .rx_clk_out_0 (rx_clk_out_0),

 
    .s_axi_aclk_0 (s_axi_aclk_0),
    .s_axi_aresetn_0 (s_axi_aresetn_0),
    .s_axi_awaddr_0 (s_axi_awaddr_0),
    .s_axi_awvalid_0 (s_axi_awvalid_0),
    .s_axi_awready_0 (s_axi_awready_0),
    .s_axi_wdata_0 (s_axi_wdata_0),
    .s_axi_wstrb_0 (s_axi_wstrb_0),
    .s_axi_wvalid_0 (s_axi_wvalid_0),
    .s_axi_wready_0 (s_axi_wready_0),
    .s_axi_bresp_0 (s_axi_bresp_0),
    .s_axi_bvalid_0 (s_axi_bvalid_0),
    .s_axi_bready_0 (s_axi_bready_0),
    .s_axi_araddr_0 (s_axi_araddr_0),
    .s_axi_arvalid_0 (s_axi_arvalid_0),
    .s_axi_arready_0 (s_axi_arready_0),
    .s_axi_rdata_0 (s_axi_rdata_0),
    .s_axi_rresp_0 (s_axi_rresp_0),
    .s_axi_rvalid_0 (s_axi_rvalid_0),
    .s_axi_rready_0 (s_axi_rready_0),
    .pm_tick_0 (pm_tick_0),
    .rx_reset_0 (rx_reset_0),
    .user_rx_reset_0 (user_rx_reset_0),
    .rxrecclkout_0 (rxrecclkout_0),

    .user_reg0_0 (user_reg0_0),

//// RX User Interface Signals
    .rx_axis_tvalid_0 (rx_axis_tvalid_0),
    .rx_axis_tdata_0 (rx_axis_tdata_0),
    .rx_axis_tlast_0 (rx_axis_tlast_0),
    .rx_axis_tkeep_0 (rx_axis_tkeep_0),
    .rx_axis_tuser_0 (rx_axis_tuser_0),
    .rx_preambleout_0 (rx_preambleout_0),

    .tx_ptp_1588op_in_0 (tx_ptp_1588op_in_0),
    .tx_ptp_tag_field_in_0 (tx_ptp_tag_field_in_0),
    .tx_ptp_tstamp_valid_out_0 (tx_ptp_tstamp_valid_out_0),
    .tx_ptp_tstamp_tag_out_0 (tx_ptp_tstamp_tag_out_0),
    .tx_ptp_tstamp_out_0 (tx_ptp_tstamp_out_0),
    .rx_ptp_tstamp_valid_out_0 (rx_ptp_tstamp_valid_out_0),
    .rx_ptp_tstamp_out_0 (rx_ptp_tstamp_out_0),
 
    .tx_ptp_upd_chksum_in_0 (tx_ptp_upd_chksum_in_0),
    .tx_ptp_tstamp_offset_in_0 (tx_ptp_tstamp_offset_in_0),
    .tx_ptp_chksum_offset_in_0 (tx_ptp_chksum_offset_in_0),

//// RX Control Signals


    .ctl_rx_systemtimerin_0 (ctl_rx_systemtimerin_0),
    .ctl_tx_systemtimerin_0 (ctl_tx_systemtimerin_0),


//// RX Stats Signals
    .stat_rx_block_lock_0 (stat_rx_block_lock_0),
    .stat_rx_framing_err_valid_0 (stat_rx_framing_err_valid_0),
    .stat_rx_framing_err_0 (stat_rx_framing_err_0),
    .stat_rx_hi_ber_0 (stat_rx_hi_ber_0),
    .stat_rx_valid_ctrl_code_0 (stat_rx_valid_ctrl_code_0),
    .stat_rx_bad_code_0 (stat_rx_bad_code_0),
    .stat_rx_total_packets_0 (stat_rx_total_packets_0),
    .stat_rx_total_good_packets_0 (stat_rx_total_good_packets_0),
    .stat_rx_total_bytes_0 (stat_rx_total_bytes_0),
    .stat_rx_total_good_bytes_0 (stat_rx_total_good_bytes_0),
    .stat_rx_packet_small_0 (stat_rx_packet_small_0),
    .stat_rx_jabber_0 (stat_rx_jabber_0),
    .stat_rx_packet_large_0 (stat_rx_packet_large_0),
    .stat_rx_oversize_0 (stat_rx_oversize_0),
    .stat_rx_undersize_0 (stat_rx_undersize_0),
    .stat_rx_toolong_0 (stat_rx_toolong_0),
    .stat_rx_fragment_0 (stat_rx_fragment_0),
    .stat_rx_packet_64_bytes_0 (stat_rx_packet_64_bytes_0),
    .stat_rx_packet_65_127_bytes_0 (stat_rx_packet_65_127_bytes_0),
    .stat_rx_packet_128_255_bytes_0 (stat_rx_packet_128_255_bytes_0),
    .stat_rx_packet_256_511_bytes_0 (stat_rx_packet_256_511_bytes_0),
    .stat_rx_packet_512_1023_bytes_0 (stat_rx_packet_512_1023_bytes_0),
    .stat_rx_packet_1024_1518_bytes_0 (stat_rx_packet_1024_1518_bytes_0),
    .stat_rx_packet_1519_1522_bytes_0 (stat_rx_packet_1519_1522_bytes_0),
    .stat_rx_packet_1523_1548_bytes_0 (stat_rx_packet_1523_1548_bytes_0),
    .stat_rx_bad_fcs_0 (stat_rx_bad_fcs_0),
    .stat_rx_packet_bad_fcs_0 (stat_rx_packet_bad_fcs_0),
    .stat_rx_stomped_fcs_0 (stat_rx_stomped_fcs_0),
    .stat_rx_packet_1549_2047_bytes_0 (stat_rx_packet_1549_2047_bytes_0),
    .stat_rx_packet_2048_4095_bytes_0 (stat_rx_packet_2048_4095_bytes_0),
    .stat_rx_packet_4096_8191_bytes_0 (stat_rx_packet_4096_8191_bytes_0),
    .stat_rx_packet_8192_9215_bytes_0 (stat_rx_packet_8192_9215_bytes_0),
    .stat_rx_unicast_0 (stat_rx_unicast_0),
    .stat_rx_multicast_0 (stat_rx_multicast_0),
    .stat_rx_broadcast_0 (stat_rx_broadcast_0),
    .stat_rx_vlan_0 (stat_rx_vlan_0),
    .stat_rx_inrangeerr_0 (stat_rx_inrangeerr_0),
    .stat_rx_bad_preamble_0 (stat_rx_bad_preamble_0),
    .stat_rx_bad_sfd_0 (stat_rx_bad_sfd_0),
    .stat_rx_got_signal_os_0 (stat_rx_got_signal_os_0),
    .stat_rx_test_pattern_mismatch_0 (stat_rx_test_pattern_mismatch_0),
    .stat_rx_truncated_0 (stat_rx_truncated_0),
    .stat_rx_local_fault_0 (stat_rx_local_fault_0),
    .stat_rx_remote_fault_0 (stat_rx_remote_fault_0),
    .stat_rx_internal_local_fault_0 (stat_rx_internal_local_fault_0),
    .stat_rx_received_local_fault_0 (stat_rx_received_local_fault_0),
   .stat_rx_status_0 (stat_rx_status_0),

  .stat_tx_ptp_fifo_read_error_0 (stat_tx_ptp_fifo_read_error_0),
  .stat_tx_ptp_fifo_write_error_0 (stat_tx_ptp_fifo_write_error_0),
  .tx_period_ns_0 (tx_period_ns_0),
  .rx_period_ns_0 (rx_period_ns_0),
  .tx_reset_0 (tx_reset_0),
  .user_tx_reset_0 (user_tx_reset_0),
//// TX User Interface Signals
    .tx_axis_tready_0 (tx_axis_tready_0),
    .tx_axis_tvalid_0 (tx_axis_tvalid_0),
    .tx_axis_tdata_0 (tx_axis_tdata_0),
    .tx_axis_tlast_0 (tx_axis_tlast_0),
    .tx_axis_tkeep_0 (tx_axis_tkeep_0),
    .tx_axis_tuser_0 (tx_axis_tuser_0),
    .tx_unfout_0 (tx_unfout_0),
    .tx_preamblein_0 (tx_preamblein_0),

//// TX Control Signals
    .ctl_tx_send_lfi_0 (ctl_tx_send_lfi_0),
    .ctl_tx_send_rfi_0 (ctl_tx_send_rfi_0),
    .ctl_tx_send_idle_0 (ctl_tx_send_idle_0),

    .ctl_tx_pause_req_0 (ctl_tx_pause_req_0),
    .ctl_tx_resend_pause_0 (ctl_tx_resend_pause_0),

//// TX Stats Signals
    .stat_tx_total_packets_0 (stat_tx_total_packets_0),
    .stat_tx_total_bytes_0 (stat_tx_total_bytes_0),
    .stat_tx_total_good_packets_0 (stat_tx_total_good_packets_0),
    .stat_tx_total_good_bytes_0 (stat_tx_total_good_bytes_0),
    .stat_tx_packet_64_bytes_0 (stat_tx_packet_64_bytes_0),
    .stat_tx_packet_65_127_bytes_0 (stat_tx_packet_65_127_bytes_0),
    .stat_tx_packet_128_255_bytes_0 (stat_tx_packet_128_255_bytes_0),
    .stat_tx_packet_256_511_bytes_0 (stat_tx_packet_256_511_bytes_0),
    .stat_tx_packet_512_1023_bytes_0 (stat_tx_packet_512_1023_bytes_0),
    .stat_tx_packet_1024_1518_bytes_0 (stat_tx_packet_1024_1518_bytes_0),
    .stat_tx_packet_1519_1522_bytes_0 (stat_tx_packet_1519_1522_bytes_0),
    .stat_tx_packet_1523_1548_bytes_0 (stat_tx_packet_1523_1548_bytes_0),
    .stat_tx_packet_small_0 (stat_tx_packet_small_0),
    .stat_tx_packet_large_0 (stat_tx_packet_large_0),
    .stat_tx_packet_1549_2047_bytes_0 (stat_tx_packet_1549_2047_bytes_0),
    .stat_tx_packet_2048_4095_bytes_0 (stat_tx_packet_2048_4095_bytes_0),
    .stat_tx_packet_4096_8191_bytes_0 (stat_tx_packet_4096_8191_bytes_0),
    .stat_tx_packet_8192_9215_bytes_0 (stat_tx_packet_8192_9215_bytes_0),
    .stat_tx_unicast_0 (stat_tx_unicast_0),
    .stat_tx_multicast_0 (stat_tx_multicast_0),
    .stat_tx_broadcast_0 (stat_tx_broadcast_0),
    .stat_tx_vlan_0 (stat_tx_vlan_0),
    .stat_tx_bad_fcs_0 (stat_tx_bad_fcs_0),
    .stat_tx_frame_error_0 (stat_tx_frame_error_0),
    .stat_tx_local_fault_0 (stat_tx_local_fault_0),

    .stat_tx_pause_0 (stat_tx_pause_0),
    .stat_tx_user_pause_0 (stat_tx_user_pause_0),
    .stat_tx_pause_valid_0 (stat_tx_pause_valid_0),


    .gt_dmonitorout_0 (gt_dmonitorout_0),
    .gt_eyescandataerror_0 (gt_eyescandataerror_0),
    .gt_eyescanreset_0 (gt_eyescanreset_0),
    .gt_eyescantrigger_0 (gt_eyescantrigger_0),
    .gt_pcsrsvdin_0 (gt_pcsrsvdin_0),
    .gt_rxbufreset_0 (gt_rxbufreset_0),
    .gt_rxbufstatus_0 (gt_rxbufstatus_0),
    .gt_rxcdrhold_0 (gt_rxcdrhold_0),
    .gt_rxcommadeten_0 (gt_rxcommadeten_0),
    .gt_rxdfeagchold_0 (gt_rxdfeagchold_0),
    .gt_rxdfelpmreset_0 (gt_rxdfelpmreset_0),
    .gt_rxlatclk_0 (gt_rxlatclk_0),
    .gt_rxlpmen_0 (gt_rxlpmen_0),
    .gt_rxpcsreset_0 (gt_rxpcsreset_0),
    .gt_rxpmareset_0 (gt_rxpmareset_0),
    .gt_rxpolarity_0 (gt_rxpolarity_0),
    .gt_rxprbscntreset_0 (gt_rxprbscntreset_0),
    .gt_rxprbserr_0 (gt_rxprbserr_0),
    .gt_rxprbslocked_0 (gt_rxprbslocked_0),
    .gt_txresetdone_0 (gt_txresetdone_0),
    .gt_rxprbssel_0 (gt_rxprbssel_0),
    .gt_rxrate_0 (gt_rxrate_0),
    .gt_rxslide_in_0 (gt_rxslide_in_0),
    .gt_rxstartofseq_0 (gt_rxstartofseq_0),
    .gt_txbufstatus_0 (gt_txbufstatus_0),
    .gt_txinhibit_0 (gt_txinhibit_0),
    .gt_txlatclk_0 (gt_txlatclk_0),
    .gt_txmaincursor_0 (gt_txmaincursor_0),
    .gt_txpcsreset_0 (gt_txpcsreset_0),
    .gt_txpmareset_0 (gt_txpmareset_0),
    .gt_txpolarity_0 (gt_txpolarity_0),
    .gt_txpostcursor_0 (gt_txpostcursor_0),
    .gt_txprbsforceerr_0 (gt_txprbsforceerr_0),
    .gt_txelecidle_0 (gt_txelecidle_0),
    .gt_txprbssel_0 (gt_txprbssel_0),
    .gt_txprecursor_0 (gt_txprecursor_0),
    .gt_txdiffctrl_0(gt_txdiffctrl_0),
    .gt_drpdo_0 (gt_drpdo_0),
    .gt_drprdy_0 (gt_drprdy_0),
    .gt_drpen_0 (gt_drpen_0),
    .gt_drpwe_0 (gt_drpwe_0),
    .gt_drpaddr_0 (gt_drpaddr_0),
    .gt_drpdi_0 (gt_drpdi_0),
    .gt_drpclk_0 (dclk),
    .gt_drprst_0 (1'b0),
    .gtwiz_reset_tx_datapath_0 (gtwiz_reset_tx_datapath_0),
    .gtwiz_reset_rx_datapath_0 (gtwiz_reset_rx_datapath_0),
    .gtpowergood_out_0 (gtpowergood_out_0),
    .txoutclksel_in_0 (txoutclksel_in_0),
    .rxoutclksel_in_0 (rxoutclksel_in_0),
    .qpllreset_in_0 (qpllreset_in_0),
    .gt_refclk_p (gt_refclk_p),
    .gt_refclk_n (gt_refclk_n),
    .gt_refclk_out (gt_refclk_out),
    .sys_reset (sys_reset),
    .dclk (dclk)
);





ethernet_0_pkt_gen_mon #(
.PKT_NUM (PKT_NUM))i_ethernet_0_pkt_gen_mon_0
(
  .gen_clk (tx_clk_out_0),
 
  .mon_clk (rx_core_clk_0),
  .dclk (dclk),
  .sys_reset (sys_reset),
  .restart_tx_rx (restart_tx_rx_0),
  .send_continuous_pkts (send_continous_pkts_0),
//// User Interface signals
  .completion_status (completion_status_0),
  
//// Trans debug  prots
  .gt_dmonitorout (gt_dmonitorout_0),
  .gt_eyescandataerror (gt_eyescandataerror_0),
  .gt_eyescanreset (gt_eyescanreset_0),
  .gt_eyescantrigger (gt_eyescantrigger_0),
  .gt_pcsrsvdin (gt_pcsrsvdin_0),
  .gt_rxbufreset (gt_rxbufreset_0),
  .gt_rxbufstatus (gt_rxbufstatus_0),
  .gt_rxcdrhold (gt_rxcdrhold_0),
  .gt_rxcommadeten (gt_rxcommadeten_0),
  .gt_rxdfeagchold (gt_rxdfeagchold_0),
  .gt_rxdfelpmreset (gt_rxdfelpmreset_0),
  .gt_rxlatclk (gt_rxlatclk_0),
  .gt_rxlpmen (gt_rxlpmen_0),
  .gt_rxpcsreset (gt_rxpcsreset_0),
  .gt_rxpmareset (gt_rxpmareset_0),
  .gt_rxpolarity (gt_rxpolarity_0),
  .gt_rxprbscntreset (gt_rxprbscntreset_0),
  .gt_rxprbserr (gt_rxprbserr_0),
  .gt_rxprbslocked (gt_rxprbslocked_0),
  .gt_txresetdone (gt_txresetdone_0),
  .gt_rxprbssel (gt_rxprbssel_0),
  .gt_rxrate (gt_rxrate_0),
  .gt_rxslide_in (gt_rxslide_in_0),
  .gt_rxstartofseq (gt_rxstartofseq_0),
  .gt_txbufstatus (gt_txbufstatus_0),
  .gt_txinhibit (gt_txinhibit_0),
  .gt_txlatclk (gt_txlatclk_0),
  .gt_txmaincursor (gt_txmaincursor_0),
  .gt_txpcsreset (gt_txpcsreset_0),
  .gt_txpmareset (gt_txpmareset_0),
  .gt_txpolarity (gt_txpolarity_0),
  .gt_txpostcursor (gt_txpostcursor_0),
  .gt_txprbsforceerr (gt_txprbsforceerr_0),
  .gt_txelecidle (gt_txelecidle_0),
  .gt_txprbssel (gt_txprbssel_0),
  .gt_txprecursor (gt_txprecursor_0),
  .gt_txdiffctrl(gt_txdiffctrl_0),
//// GT DRP prots
  .gt_drpdo (gt_drpdo_0),
  .gt_drprdy (gt_drprdy_0),
  .gt_drpen (gt_drpen_0),
  .gt_drpwe (gt_drpwe_0),
  .gt_drpaddr (gt_drpaddr_0),
  .gt_drpdi (gt_drpdi_0),
  .gtwiz_reset_tx_datapath (gtwiz_reset_tx_datapath_0),
  .gtwiz_reset_rx_datapath (gtwiz_reset_rx_datapath_0),
    .stat_reg_compare (stat_reg_compare_0),
//// AXI4 Lite Interface Signals
  .s_axi_aclk (s_axi_aclk_0),
  .s_axi_aresetn (s_axi_aresetn_0),
  .s_axi_awaddr (s_axi_awaddr_0),
  .s_axi_awvalid (s_axi_awvalid_0),
  .s_axi_awready (s_axi_awready_0),
  .s_axi_wdata (s_axi_wdata_0),
  .s_axi_wstrb (s_axi_wstrb_0),
  .s_axi_wvalid (s_axi_wvalid_0),
  .s_axi_wready (s_axi_wready_0),
  .s_axi_bresp (s_axi_bresp_0),
  .s_axi_bvalid (s_axi_bvalid_0),
  .s_axi_bready (s_axi_bready_0),
  .s_axi_araddr (s_axi_araddr_0),
  .s_axi_arvalid (s_axi_arvalid_0),
  .s_axi_arready (s_axi_arready_0),
  .s_axi_rdata (s_axi_rdata_0),
  .s_axi_rresp (s_axi_rresp_0),
  .s_axi_rvalid (s_axi_rvalid_0),
  .s_axi_rready (s_axi_rready_0),
  .pm_tick (pm_tick_0),
//// RX Signals
  .rx_reset(rx_reset_0),
  
  .user_rx_reset(user_rx_reset_0),

  .rx_axis_tvalid (rx_axis_tvalid_0),
  .rx_axis_tdata (rx_axis_tdata_0),
  .rx_axis_tlast (rx_axis_tlast_0),
  .rx_axis_tkeep (rx_axis_tkeep_0),
  .rx_axis_tuser (rx_axis_tuser_0),
  .rx_preambleout (rx_preambleout_0),

  .tx_ptp_1588op_in (tx_ptp_1588op_in_0),
  .tx_ptp_tag_field_in (tx_ptp_tag_field_in_0),
  .tx_ptp_tstamp_valid_out (tx_ptp_tstamp_valid_out_0),
  .tx_ptp_tstamp_tag_out (tx_ptp_tstamp_tag_out_0),
  .tx_ptp_tstamp_out (tx_ptp_tstamp_out_0),
  .rx_ptp_tstamp_valid_out (rx_ptp_tstamp_valid_out_0),
  .rx_ptp_tstamp_out (rx_ptp_tstamp_out_0),
 
  .tx_ptp_upd_chksum_in (tx_ptp_upd_chksum_in_0),
  .tx_ptp_tstamp_offset_in (tx_ptp_tstamp_offset_in_0),
  .tx_ptp_chksum_offset_in (tx_ptp_chksum_offset_in_0),

//// RX Control Signals


  .ctl_rx_systemtimerin (),
  .ctl_tx_systemtimerin (),
//// RX Stats Signals
  .stat_rx_block_lock (stat_rx_block_lock_0),
  .stat_rx_framing_err_valid (stat_rx_framing_err_valid_0),
  .stat_rx_framing_err (stat_rx_framing_err_0),
  .stat_rx_hi_ber (stat_rx_hi_ber_0),
  .stat_rx_valid_ctrl_code (stat_rx_valid_ctrl_code_0),
  .stat_rx_bad_code (stat_rx_bad_code_0),
  .stat_rx_total_packets (stat_rx_total_packets_0),
  .stat_rx_total_good_packets (stat_rx_total_good_packets_0),
  .stat_rx_total_bytes (stat_rx_total_bytes_0),
  .stat_rx_total_good_bytes (stat_rx_total_good_bytes_0),
  .stat_rx_packet_small (stat_rx_packet_small_0),
  .stat_rx_jabber (stat_rx_jabber_0),
  .stat_rx_packet_large (stat_rx_packet_large_0),
  .stat_rx_oversize (stat_rx_oversize_0),
  .stat_rx_undersize (stat_rx_undersize_0),
  .stat_rx_toolong (stat_rx_toolong_0),
  .stat_rx_fragment (stat_rx_fragment_0),
  .stat_rx_packet_64_bytes (stat_rx_packet_64_bytes_0),
  .stat_rx_packet_65_127_bytes (stat_rx_packet_65_127_bytes_0),
  .stat_rx_packet_128_255_bytes (stat_rx_packet_128_255_bytes_0),
  .stat_rx_packet_256_511_bytes (stat_rx_packet_256_511_bytes_0),
  .stat_rx_packet_512_1023_bytes (stat_rx_packet_512_1023_bytes_0),
  .stat_rx_packet_1024_1518_bytes (stat_rx_packet_1024_1518_bytes_0),
  .stat_rx_packet_1519_1522_bytes (stat_rx_packet_1519_1522_bytes_0),
  .stat_rx_packet_1523_1548_bytes (stat_rx_packet_1523_1548_bytes_0),
  .stat_rx_bad_fcs (stat_rx_bad_fcs_0),
  .stat_rx_packet_bad_fcs (stat_rx_packet_bad_fcs_0),
  .stat_rx_stomped_fcs (stat_rx_stomped_fcs_0),
  .stat_rx_packet_1549_2047_bytes (stat_rx_packet_1549_2047_bytes_0),
  .stat_rx_packet_2048_4095_bytes (stat_rx_packet_2048_4095_bytes_0),
  .stat_rx_packet_4096_8191_bytes (stat_rx_packet_4096_8191_bytes_0),
  .stat_rx_packet_8192_9215_bytes (stat_rx_packet_8192_9215_bytes_0),
  .stat_rx_unicast (stat_rx_unicast_0),
  .stat_rx_multicast (stat_rx_multicast_0),
  .stat_rx_broadcast (stat_rx_broadcast_0),
  .stat_rx_vlan (stat_rx_vlan_0),
  .stat_rx_inrangeerr (stat_rx_inrangeerr_0),
  .stat_rx_bad_preamble (stat_rx_bad_preamble_0),
  .stat_rx_bad_sfd (stat_rx_bad_sfd_0),
  .stat_rx_got_signal_os (stat_rx_got_signal_os_0),
  .stat_rx_test_pattern_mismatch (stat_rx_test_pattern_mismatch_0),
  .stat_rx_truncated (stat_rx_truncated_0),
  .stat_rx_local_fault (stat_rx_local_fault_0),
  .stat_rx_remote_fault (stat_rx_remote_fault_0),
  .stat_rx_internal_local_fault (stat_rx_internal_local_fault_0),
  .stat_rx_received_local_fault (stat_rx_received_local_fault_0),


  .stat_tx_ptp_fifo_read_error (stat_tx_ptp_fifo_read_error_0),
  .stat_tx_ptp_fifo_write_error (stat_tx_ptp_fifo_write_error_0),
  .tx_reset(tx_reset_0),
  
  .user_tx_reset (user_tx_reset_0),

//// TX AXIS Signals
  .tx_axis_tready (tx_axis_tready_0),
  .tx_axis_tvalid (tx_axis_tvalid_0),
  .tx_axis_tdata (tx_axis_tdata_0),
  .tx_axis_tlast (tx_axis_tlast_0),
  .tx_axis_tkeep (tx_axis_tkeep_0),
  .tx_axis_tuser (tx_axis_tuser_0),
  .tx_unfout (tx_unfout_0),
  .tx_preamblein (tx_preamblein_0),
//// TX Control Signals
  .ctl_tx_send_lfi (ctl_tx_send_lfi_0),
  .ctl_tx_send_rfi (ctl_tx_send_rfi_0),
  .ctl_tx_send_idle (ctl_tx_send_idle_0),

  .ctl_tx_pause_req (ctl_tx_pause_req_0),
  .ctl_tx_resend_pause (ctl_tx_resend_pause_0),

//// TX Stats Signals
  .stat_tx_total_packets (stat_tx_total_packets_0),
  .stat_tx_total_bytes (stat_tx_total_bytes_0),
  .stat_tx_total_good_packets (stat_tx_total_good_packets_0),
  .stat_tx_total_good_bytes (stat_tx_total_good_bytes_0),
  .stat_tx_packet_64_bytes (stat_tx_packet_64_bytes_0),
  .stat_tx_packet_65_127_bytes (stat_tx_packet_65_127_bytes_0),
  .stat_tx_packet_128_255_bytes (stat_tx_packet_128_255_bytes_0),
  .stat_tx_packet_256_511_bytes (stat_tx_packet_256_511_bytes_0),
  .stat_tx_packet_512_1023_bytes (stat_tx_packet_512_1023_bytes_0),
  .stat_tx_packet_1024_1518_bytes (stat_tx_packet_1024_1518_bytes_0),
  .stat_tx_packet_1519_1522_bytes (stat_tx_packet_1519_1522_bytes_0),
  .stat_tx_packet_1523_1548_bytes (stat_tx_packet_1523_1548_bytes_0),
  .stat_tx_packet_small (stat_tx_packet_small_0),
  .stat_tx_packet_large (stat_tx_packet_large_0),
  .stat_tx_packet_1549_2047_bytes (stat_tx_packet_1549_2047_bytes_0),
  .stat_tx_packet_2048_4095_bytes (stat_tx_packet_2048_4095_bytes_0),
  .stat_tx_packet_4096_8191_bytes (stat_tx_packet_4096_8191_bytes_0),
  .stat_tx_packet_8192_9215_bytes (stat_tx_packet_8192_9215_bytes_0),
  .stat_tx_unicast (stat_tx_unicast_0),
  .stat_tx_multicast (stat_tx_multicast_0),
  .stat_tx_broadcast (stat_tx_broadcast_0),
  .stat_tx_vlan (stat_tx_vlan_0),
  .stat_tx_bad_fcs (stat_tx_bad_fcs_0),
  .stat_tx_frame_error (stat_tx_frame_error_0),
  .stat_tx_local_fault (stat_tx_local_fault_0),

  .stat_tx_pause (stat_tx_pause_0),
  .stat_tx_user_pause (stat_tx_user_pause_0),
  .stat_tx_pause_valid (stat_tx_pause_valid_0),
   
  .rx_gt_locked_led (rx_gt_locked_led_0),
  .rx_block_lock_led (block_lock_led_0)

    );



assign completion_status = completion_status_0;
assign stat_reg_compare = stat_reg_compare_0;

endmodule







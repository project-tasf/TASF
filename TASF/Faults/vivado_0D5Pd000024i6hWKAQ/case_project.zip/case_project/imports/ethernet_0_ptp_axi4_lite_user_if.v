////------------------------------------------------------------------------------
//// Copyright 2015 Advanced Micro Devices, Inc. All rights reserved.
//// This file contains confidential and proprietary information of Advanced Micro Devices, Inc.
//// and is protected under U.S. and international copyright and other
//// intellectual property laws.
////
////  DISCLAIMER
////  This disclaimer is not a license and does not grant any
////  rights to the materials distributed herewith. Except as
////  otherwise provided in a valid license issued to you by
////  AMD, and to the maximum extent permitted by applicable
////  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
////  WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
////  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
////  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
////  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
////  (2) AMD shall not be liable (whether in contract or tort,
////  including negligence, or under any other theory of
////  liability) for any loss or damage of any kind or nature
////  related to, arising under or in connection with these
////  materials, including for any direct, or any indirect,
////  special, incidental, or consequential loss or damage
////  (including loss of data, profits, goodwill, or any type of
////  loss or damage suffered as a result of any action brought
////  by a third party) even if such damage or loss was
////  reasonably foreseeable or AMD had been advised of the
////  possibility of the same.
////
////  CRITICAL APPLICATIONS
////  AMD products are not designed or intended to be fail-
////  safe, or for use in any application requiring fail-safe
////  performance, such as life-support or safety devices or
////  systems, Class III medical devices, nuclear facilities,
////  applications related to the deployment of airbags, or any
////  other applications that could lead to death, personal
////  injury, or severe property or environmental damage
////  (individually and collectively, "Critical
////  Applications"). Customer assumes the sole risk and
////  liability of any use of AMD products in Critical
////  Applications, subject only to applicable laws and
////  regulations governing limitations on product liability.
////
////  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
////  PART OF THIS FILE AT ALL TIMES.
////------------------------------------------------------------------------------

`timescale 1fs/1fs
(* DowngradeIPIdentifiedWarnings="yes" *)

module ethernet_0_ptp_axi4_lite_user_if
   (
    input  wire            stat_rx_aligned,
  

    input                  s_axi_aclk,
    input                  s_axi_sreset,
    output  [31:0]         s_axi_awaddr,
    output                 s_axi_awvalid,
    
    input                  s_axi_awready,
    
    output  [31:0]         s_axi_wdata,
    output  [3:0]          s_axi_wstrb,
    output                 s_axi_wvalid,
    input                  s_axi_wready,
    
    input   [1:0]          s_axi_bresp,
    input                  s_axi_bvalid,
    output                 s_axi_bready,
    
    output  [31:0]         s_axi_araddr,
    output                 s_axi_arvalid,
    input                  s_axi_arready,
    input   [31:0]         s_axi_rdata,
    input   [1:0]          s_axi_rresp,
    input                  s_axi_rvalid,
    output                 s_axi_rready

    );
    //// axi_user_prestate
    parameter STATE_AXI_IDLE            = 0;
    parameter STATE_AXI_WR              = 1;
    parameter STATE_AXI_RD_WR           = 2;
    parameter STATE_TEST_DONE           = 3;

    // PTP TIMER SYNCER REGISTERS
    parameter  PTP_TOD_CONFIG          =  32'h00000000;  // TOD Config value 32'h11; (4 port F1, 3 port 71, 2 port 31)
    parameter  PTP_TOD_NS_CONFIG       =  32'h00000018;  // TOD Config NS value 32'h77;
    parameter  PTP_TOD_SEC_LSB_CONFIG  =  32'h00000010;  // TOD Config NS value 32'h5;
    parameter  PTP_TOD_SEC_MSB_CONFIG  =  32'h00000014;  // TOD Config NS value 32'h1;
    parameter  PTP_TOD_TX0_PERIOD_LSB_CONFIG  =  32'h00000208;  // TOD Config NS value 32'h66666666;
    parameter  PTP_TOD_TX0_PERIOD_MSB_CONFIG  =  32'h0000020C;  // TOD Config NS value 32'h00066666;
    parameter  PTP_TOD_RX0_PERIOD_LSB_CONFIG  =  32'h00000228;  // TOD Config NS value 32'h66666666;
    parameter  PTP_TOD_RX0_PERIOD_MSB_CONFIG  =  32'h0000022C;  // TOD Config NS value 32'h00066666;
  
  
    parameter  PTP_TOD_SW_LOAD_CONFIG  =  32'h0000001C;  // TOD Config NS value 32'h1;

    ////State Registers for TX
    reg  [2:0]     axi_user_prestate;

    reg  [31:0]    axi_wr_data;
    reg  [31:0]    axi_read_data;
    wire [31:0]    axi_rd_data;
    reg  [31:0]    axi_wr_addr, axi_rd_addr;
    reg  [3:0]     axi_wr_strobe;
    reg            axi_wr_data_valid;
    reg            axi_wr_addr_valid;
    reg            axi_rd_addr_valid;
    reg            axi_rd_req;
    reg            axi_wr_req;
    wire           axi_wr_ack;
    wire           axi_rd_ack;
    wire           axi_wr_err;
    wire           axi_rd_err;
    reg  [7:0]     rd_wr_cntr;
    wire           stat_rx_aligned_sync;
  


    //////////////////////////////////////////////////
    ////State Machine 
    //////////////////////////////////////////////////
    always @( posedge s_axi_aclk )
    begin
        if ( s_axi_sreset == 1'b1 )
        begin
            axi_user_prestate         <= STATE_AXI_IDLE;
            axi_rd_addr               <= 32'd0;
            axi_rd_addr_valid         <= 1'b0;
            axi_wr_data               <= 32'd0;
            axi_read_data             <= 32'd0;
            axi_wr_addr               <= 32'd0;
            axi_wr_addr_valid         <= 1'b0;
            axi_wr_data_valid         <= 1'b0;
            axi_wr_strobe             <= 4'd0;
            axi_rd_req                <= 1'b0;
            axi_wr_req                <= 1'b0;
            rd_wr_cntr                <= 8'd0;
        end
        else
        begin
        case (axi_user_prestate)
            STATE_AXI_IDLE            :
                                     begin
                                         axi_rd_addr               <= 32'd0;
                                         axi_rd_addr_valid         <= 1'b0;
                                         axi_wr_data               <= 32'd0;
                                         axi_read_data             <= 32'd0;
                                         axi_wr_addr               <= 32'd0;
                                         axi_wr_addr_valid         <= 1'b0;
                                         axi_wr_data_valid         <= 1'b0;
                                         axi_wr_strobe             <= 4'd0;
                                         axi_rd_req                <= 1'b0;
                                         axi_wr_req                <= 1'b0;
                                         rd_wr_cntr                <= 8'd0;

                                         //// State transition
                                         if  (stat_rx_aligned_sync == 1'b1)
                                         begin
                                             axi_user_prestate <= STATE_AXI_WR;
                                         end
                                         else
                                             axi_user_prestate <= STATE_AXI_IDLE;
                                     end

                      STATE_AXI_WR   :
                                     begin
                                         
                                         case (rd_wr_cntr)
                                             'd0     : begin
                                                           $display( "           AXI4 Lite Write Started to Config TIMER SYNCER IP ..." );
                                                           axi_wr_addr             <= PTP_TOD_CONFIG;    ////TOD Config
                                                           axi_wr_data             <= 32'h0001_0011;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd1     : begin
                                                           axi_wr_addr             <= PTP_TOD_NS_CONFIG;    ////TOD_NS_CONFIG
                                                           axi_wr_data             <= 32'h0000_0077;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd2     : begin
                                                           axi_wr_addr             <= PTP_TOD_SEC_LSB_CONFIG;    ////TOD_SEC_LSB_CONFIG
                                                           axi_wr_data             <= 32'h0000_0005;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd3     : begin
                                                           axi_wr_addr             <= PTP_TOD_SEC_MSB_CONFIG;    ////TOD_SEC_MSB_CONFIG
                                                           axi_wr_data             <= 32'h0000_0001;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd4     : begin
                                                           axi_wr_addr             <= PTP_TOD_TX0_PERIOD_LSB_CONFIG;    ////TOD_TX0_PERIOD_LSB_CONFIG
                                                           axi_wr_data             <= 32'h6666_6666;
  
  
  
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd5     : begin
                                                           axi_wr_addr             <= PTP_TOD_TX0_PERIOD_MSB_CONFIG;    ////TOD_TX0_PERIOD_MSB_CONFIG
                                                           axi_wr_data             <= 32'h0006_6666;
  
  
  
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd6    : begin
                                                           axi_wr_addr             <= PTP_TOD_RX0_PERIOD_LSB_CONFIG;    ////TOD_RX0_PERIOD_LSB_CONFIG
                                                           axi_wr_data             <= 32'h6666_6666;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd7     : begin
                                                           axi_wr_addr             <= PTP_TOD_RX0_PERIOD_MSB_CONFIG;    ////TOD_RX0_PERIOD_MSB_CONFIG
                                                           axi_wr_data             <= 32'h0006_6666;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd8    : begin
                                                           axi_wr_addr             <= PTP_TOD_SW_LOAD_CONFIG;    ////TOD_SW_LOAD_CONFIG
                                                           axi_wr_data             <= 32'h0000_0001;
                                                           axi_wr_addr_valid       <= 1'b1;
                                                           axi_wr_data_valid       <= 1'b1;
                                                           axi_wr_strobe           <= 4'hF;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b1;
                                                       end
                                             'd9     : begin
                                                           axi_wr_addr             <= 32'h0000_0000;    ////TOD_SW_LOAD_CONFIG
                                                           axi_wr_data             <= 32'h0000_0000;
                                                           axi_wr_addr_valid       <= 1'b0;
                                                           axi_wr_data_valid       <= 1'b0;
                                                           axi_wr_strobe           <= 4'h0;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b0;
                                                       end


                                              default : begin
                                                           axi_wr_data             <= 32'h0;
                                                           axi_wr_addr             <= 32'h0;
                                                           axi_wr_addr_valid       <= 1'b0;
                                                           axi_wr_data_valid       <= 1'b0;
                                                           axi_wr_strobe           <= 4'h0;
                                                           axi_rd_req              <= 1'b0;
                                                           axi_wr_req              <= 1'b0;
                                                       end
                                                       
                                         endcase


                                         if  (rd_wr_cntr == 8'd9)
                                         begin
                                           axi_user_prestate <= STATE_TEST_DONE;
                                           $display( "           AXI4 Lite Write Completed" );
                                         end
                                         else 
                                           axi_user_prestate <= STATE_AXI_RD_WR;
                                         end
        


            STATE_AXI_RD_WR          :
                                     begin
                                         if (s_axi_awready == 1'b1 )
                                         begin
                                             axi_wr_addr             <= 32'd0;
                                             axi_wr_addr_valid       <= 1'b0;
                                             axi_wr_req              <= 1'b0;
                                         end
                                         if (s_axi_wready == 1'b1  ) 
                                         begin
                                             axi_wr_data             <= 32'd0;
                                             axi_wr_data_valid       <= 1'b0;
                                             axi_wr_strobe           <= 4'd0;
                                         end
                                         if (s_axi_arready == 1'b1  )
                                         begin
                                             axi_rd_addr             <= 32'd0;
                                             axi_rd_addr_valid       <= 1'b0;
                                             axi_rd_req              <= 1'b0;
                                         end
                                         
                                         //// State transition
                                         if  ((axi_wr_ack == 1'b1 && axi_wr_err == 1'b1) || (axi_rd_ack == 1'b1 && axi_rd_err == 1'b1))
                                         begin
                                             $display("ERROR : INVALID AXI4 Lite READ/WRITE OPERATION OCCURED, APPLY SYS_RESET TO RECOVER ..........");
                                             axi_user_prestate <= STATE_AXI_WR;
                                         end
                                         else if  ((axi_wr_ack == 1'b1 && axi_wr_err == 1'b0) || (axi_rd_ack == 1'b1 && axi_rd_err == 1'b0))
                                         begin
                                             rd_wr_cntr              <= rd_wr_cntr + 8'd1;
                                             axi_read_data           <= axi_rd_data;

                                             if  (stat_rx_aligned_sync == 1'b1 )
                                                 axi_user_prestate <= STATE_AXI_WR;
                                             else
                                                 axi_user_prestate <= STATE_AXI_IDLE;
                                         end
                                     end
             STATE_TEST_DONE         :
                                     begin
                                         axi_rd_addr             <= 32'd0;
                                         axi_rd_addr_valid       <= 1'b0;
                                         axi_wr_data             <= 32'd0;
                                         axi_wr_addr             <= 32'd0;
                                         axi_wr_addr_valid       <= 1'b0;
                                         axi_wr_data_valid       <= 1'b0;
                                         axi_wr_strobe           <= 4'd0;
                                         axi_rd_req              <= 1'b0;
                                         axi_wr_req              <= 1'b0;
                                         rd_wr_cntr              <= 8'd0;

                                         //// State transition
                                         if  (stat_rx_aligned_sync == 1'b0 )
                                             axi_user_prestate <= STATE_AXI_IDLE;
                                         else
                                             axi_user_prestate <= STATE_TEST_DONE;
                                     end
            default                  :
                                     begin
                                         axi_rd_addr               <= 32'd0;
                                         axi_rd_addr_valid         <= 1'b0;
                                         axi_wr_data               <= 32'd0;
                                         axi_read_data             <= 32'd0;
                                         axi_wr_addr               <= 32'd0;
                                         axi_wr_addr_valid         <= 1'b0;
                                         axi_wr_data_valid         <= 1'b0;
                                         axi_wr_strobe             <= 4'd0;
                                         axi_rd_req                <= 1'b0;
                                         axi_wr_req                <= 1'b0;
                                         rd_wr_cntr                <= 8'd0;
                                         axi_user_prestate         <= STATE_AXI_IDLE;
                                     end
            endcase
        end
    end

ethernet_0_ptp_axi4_lite_rd_wr_if i_ethernet_0_ptp_axi4_lite_rd_wr_if
  (
    .axi_aclk(s_axi_aclk),
    .axi_sreset(s_axi_sreset),
    .axi_bresp(s_axi_bresp),
    .axi_bvalid(s_axi_bvalid),
    .axi_bready(s_axi_bready),
    .axi_rdata(s_axi_rdata),
    .axi_rresp(s_axi_rresp),
    .axi_rvalid(s_axi_rvalid),
    .axi_rready(s_axi_rready),
    .axi_awaddr(s_axi_awaddr),
    .axi_awvalid(s_axi_awvalid),
    .axi_awready(s_axi_awready),
    .axi_wdata(s_axi_wdata),
    .axi_wstrb(s_axi_wstrb),
    .axi_wvalid(s_axi_wvalid),
    .axi_wready(s_axi_wready),
    .axi_araddr(s_axi_araddr),
    .axi_arvalid(s_axi_arvalid),
    .axi_arready(s_axi_arready),
    .usr_write_req(axi_wr_req),
    .usr_read_req(axi_rd_req),
    .usr_rdata(axi_rd_data),
    .usr_araddr(axi_rd_addr),
    .usr_arvalid(axi_rd_addr_valid),
    .usr_awaddr(axi_wr_addr),
    .usr_awvalid(axi_wr_addr_valid),
    .usr_wdata(axi_wr_data),
    .usr_wvalid(axi_wr_data_valid),
    .usr_wstrb(axi_wr_strobe),    
    .usr_wrack(axi_wr_ack),
    .usr_rdack(axi_rd_ack),
    .usr_wrerr(axi_wr_err),
    .usr_rderr(axi_rd_err)
  );
 


   ethernet_0_ptp_cdc_sync_axi i_ethernet_0_ptp_cdc_sync_stat_rx_aligned
  (
   .clk              (s_axi_aclk),
   .signal_in        (stat_rx_aligned), 
   .signal_out       (stat_rx_aligned_sync)
  );

    ////----------------------------------------END TX Module-----------------------//

endmodule

(* DowngradeIPIdentifiedWarnings="yes" *)
module ethernet_0_ptp_axi4_lite_rd_wr_if
  (

  input  wire                    axi_aclk,
  input  wire                    axi_sreset,

  input  wire                    usr_write_req,
  input  wire                    usr_read_req,

  //// write side from usr
  input  wire [31:0]             usr_awaddr,
  input  wire                    usr_awvalid,
  input  wire [31:0]             usr_wdata,
  input  wire                    usr_wvalid,
  input  wire [3:0]              usr_wstrb,

  //// write response from axi
  input  wire [1:0]              axi_bresp,
  input  wire                    axi_bvalid,
  output wire                    axi_bready,

  //// read side from usr
  input  wire [31:0]             usr_araddr,
  input  wire                    usr_arvalid,

  //// read side from axi
  input  wire [31:0]             axi_rdata,
  input  wire [1:0]              axi_rresp,
  
  input  wire                    axi_rvalid,
  output wire                    axi_rready,
  output wire                    axi_arvalid,
  input  wire                    axi_arready,

  //// write side to axi
  output wire [31:0]             axi_awaddr,
  output wire                    axi_awvalid,
  input  wire                    axi_awready,

  output wire [31:0]             axi_wdata,
  output wire [3:0]              axi_wstrb,
  output wire                    axi_wvalid,
  input  wire                    axi_wready,

  //// read side to usr
  output wire [31:0]             usr_rdata,
  output wire [31:0]             axi_araddr, 
  output wire                    usr_wrack,
  output wire                    usr_rdack,
  output wire                    usr_wrerr,
  output wire                    usr_rderr
  );

  //// States
  parameter IDLE_STATE  = 0;
  parameter WRITE_STATE = 1;
  parameter READ_STATE  = 2;
  parameter ACK_STATE   = 3;

  reg [2:0] pstate;

  reg [31:0]             axi_awaddr_r;
  reg                    axi_awvalid_r;
  reg [31:0]             axi_wdata_r;
  reg [31:0]             axi_rdata_r;
  reg [3:0]              axi_wstrb_r;
  reg                    axi_wvalid_r;

  reg [31:0]             usr_araddr_r;
  reg                    usr_wrack_r;
  reg                    usr_rdack_r;
  reg                    usr_wrerr_r;
  reg                    usr_rderr_r;

  reg                    axi_arvalid_r;
  reg                    axi_bready_r;
  reg                    axi_rready_r;

  assign axi_awaddr   =  axi_awaddr_r;
  assign axi_awvalid  =  axi_awvalid_r;
  assign axi_wdata    =  axi_wdata_r;
  assign axi_wstrb    =  axi_wstrb_r;
  assign axi_wvalid   =  axi_wvalid_r;

  assign usr_rdata    =  axi_rdata_r;
  assign axi_bready   =  axi_bready_r;
  assign axi_rready   =  axi_rready_r;
  assign axi_arvalid  =  axi_arvalid_r;
  assign axi_araddr   =  usr_araddr_r;

  assign usr_wrack    =  usr_wrack_r;
  assign usr_rdack    =  usr_rdack_r;
  assign usr_wrerr    =  usr_wrerr_r;
  assign usr_rderr    =  usr_rderr_r;

//////////////////////////////////////////////////////////////////////////////
//// Implement axi_bready generation
////
////  axi_bready is asserted for one s_axi_aclk clock cycle when 
////  axi_bvalid is asserted. axi_bready is
////  de-asserted when reset is low.
//////////////////////////////////////////////////////////////////////////////
  always @(posedge axi_aclk)
  begin
     if (axi_sreset == 1'b1)
     begin
        axi_bready_r  <=  1'b0;
     end
     else
     begin
        if ((~axi_bready_r) && (axi_bvalid))
           axi_bready_r  <=  1'b1;
        else
           axi_bready_r  <=  1'b0;
     end
  end

//////////////////////////////////////////////////////////////////////////////
//// Implement axi_rready generation
////
////  axi_rready is asserted for one axi_aclk clock cycle when
////  axi_rvalid is asserted. axi_rready is
////  de-asserted when reset (active low) is asserted.
//////////////////////////////////////////////////////////////////////////////
  always @(posedge axi_aclk)
  begin
     if (axi_sreset == 1'b1)
     begin
        axi_rready_r  <=  1'b0;
     end
     else
     begin
        if ((~axi_rready_r) && (axi_rvalid))
           axi_rready_r  <=  1'b1;
        else
           axi_rready_r  <=  1'b0;
     end
  end

//////////////////////////////////////////////////////////////////////////////
//// State machine flow
//////////////////////////////////////////////////////////////////////////////
  always @(posedge axi_aclk)
  begin
     if (axi_sreset == 1'b1)
     begin
        pstate        <=  IDLE_STATE;

        axi_arvalid_r <=  1'b0;
        usr_araddr_r  <=  32'd0;
        axi_rdata_r   <=  32'd0;

        axi_awvalid_r <=  1'b0;
        axi_awaddr_r  <=  32'd0;
        axi_wvalid_r  <=  1'b0;
        axi_wdata_r   <=  32'd0;
        axi_wstrb_r   <=  4'd0;

        usr_wrack_r   <=  1'b0;
        usr_rdack_r   <=  1'b0;
        usr_wrerr_r   <=  1'b0;
        usr_rderr_r   <=  1'b0;
     end
     else
     begin
        case (pstate)
                IDLE_STATE    : begin
                                    if (usr_read_req == 1'b1)
                                    begin
                                       pstate        <=  READ_STATE;
                                       axi_arvalid_r <=  usr_arvalid;
                                       usr_araddr_r  <=  usr_araddr;
                                    end
                                    else if (usr_write_req == 1'b1)
                                    begin
                                       pstate        <=  WRITE_STATE;
                                       axi_awvalid_r <=  usr_awvalid;
                                       axi_awaddr_r  <=  usr_awaddr;
                                       axi_wvalid_r  <=  usr_wvalid;
                                       axi_wdata_r   <=  usr_wdata;
                                       axi_wstrb_r   <=  usr_wstrb;
                                    end
                                    else
                                    begin
                                       pstate        <=  IDLE_STATE;
                                       axi_arvalid_r <=  1'b0;
                                       usr_araddr_r  <=  32'd0;
                                       axi_rdata_r   <=  32'd0;

                                       axi_awvalid_r <=  1'b0;
                                       axi_awaddr_r  <=  32'd0;
                                       axi_wvalid_r  <=  1'b0;
                                       axi_wdata_r   <=  32'd0;
                                       axi_wstrb_r   <=  4'd0;

                                       usr_wrack_r   <=  1'b0;
                                       usr_rdack_r   <=  1'b0;
                                       usr_wrerr_r   <=  1'b0;
                                       usr_rderr_r   <=  1'b0;
                                    end
                                 end

                WRITE_STATE    : begin
                                    if ((axi_bvalid == 1'b1) && (axi_bready_r == 1'b1))
                                    begin
                                       pstate        <=  ACK_STATE;
                                       usr_wrack_r   <=  1'b1;
                                       if (axi_bresp == 2'b10)
                                          usr_wrerr_r <=  1'b1;
                                       else
                                          usr_wrerr_r <=  1'b0;
                                    end
                                    else
                                    begin
                                       pstate        <=  WRITE_STATE;
                                       axi_awvalid_r <=  usr_awvalid;
                                       axi_awaddr_r  <=  usr_awaddr;
                                       axi_wvalid_r  <=  usr_wvalid;
                                       axi_wdata_r   <=  usr_wdata;
                                       axi_wstrb_r   <=  usr_wstrb;
                                    end
                                 end

                READ_STATE     : begin
                                    if ((axi_rvalid == 1'b1) && (axi_rready_r == 1'b1)) begin
                                       pstate        <=  ACK_STATE;
                                       axi_rdata_r   <=  axi_rdata;
                                       usr_rdack_r   <=  1'b1;
                                       if (axi_rresp == 2'b10)
                                          usr_rderr_r <=  1'b1;
                                       else
                                          usr_rderr_r <=  1'b0;
                                    end
                                    else
                                    begin
                                       pstate        <=  READ_STATE;
                                       axi_arvalid_r <=  usr_arvalid;
                                       usr_araddr_r  <=  usr_araddr;
                                    end
                                 end

                ACK_STATE      : begin
                                    pstate        <=  IDLE_STATE;
                                    usr_wrack_r   <=  1'b0;
                                    usr_rdack_r   <=  1'b0;
                                    usr_wrerr_r   <=  1'b0;
                                    usr_rderr_r   <=  1'b0;
                                 end

                default        : begin
                                    pstate                   <=  IDLE_STATE;
                                    axi_arvalid_r            <=  1'b0;
                                    usr_araddr_r             <=  32'd0;
                                    axi_rdata_r              <=  32'd0;
                                    
                                    axi_awvalid_r            <=  1'b0;
                                    axi_awaddr_r             <=  32'd0;
                                    axi_wvalid_r             <=  1'b0;
                                    axi_wdata_r              <=  32'd0;
                                    axi_wstrb_r              <=  4'd0;
                                    
                                    usr_wrack_r              <=  1'b0;
                                    usr_rdack_r              <=  1'b0;
                                    usr_wrerr_r              <=  1'b0;
                                    usr_rderr_r              <=  1'b0;
                                 end
        endcase
     end
  end

endmodule


(* DowngradeIPIdentifiedWarnings="yes" *)
module ethernet_0_ptp_cdc_sync_axi (
 input clk,
 input signal_in,
 output wire signal_out
);

                          wire sig_in_cdc_from ;
 (* ASYNC_REG = "TRUE" *) reg  s_out_d2_cdc_to;
 (* ASYNC_REG = "TRUE" *) reg  s_out_d3;

assign sig_in_cdc_from = signal_in;
assign signal_out      = s_out_d3;

always @(posedge clk) 
begin
  s_out_d2_cdc_to  <= sig_in_cdc_from;
  s_out_d3         <= s_out_d2_cdc_to;
end

endmodule

set case_scope /ethernet_0_exdes_tb/EXDES/i_ethernet_0_ptp_axi4_lite_user_if_0
if {[llength [get_wave_configs -quiet]] == 0} {create_wave_config}
foreach case_signal {s_axi_aclk s_axi_sreset s_axi_awaddr s_axi_awvalid s_axi_awready s_axi_wdata s_axi_wstrb s_axi_wvalid s_axi_wready s_axi_bresp s_axi_bvalid s_axi_bready s_axi_araddr s_axi_arvalid s_axi_arready s_axi_rdata s_axi_rresp s_axi_rvalid s_axi_rready expected_value} {
 add_wave -radix hex $case_scope/$case_signal
}
run all
save_wave_config ptp_register.wcfg

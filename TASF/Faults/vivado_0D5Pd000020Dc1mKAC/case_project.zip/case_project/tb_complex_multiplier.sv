// 时间单位 1ns，时间精度 1ps；每个输入通道仅发送一个样本。
`timescale 1ns/1ps
module tb_complex_multiplier;
  reg clk=0, rstn=0;
  reg av=0,bv=0,cv=0; // 输入有效信号初始为零。
  reg [47:0] a=0;
  reg [15:0] b=0;
  wire [63:0] y;
  wire ov,out_last;
  bit mismatch=0; // 本次有效输出是否与模型预期不一致。
  reg signed [31:0] actual_re,actual_im;
  // ===== 事务级整数参考模型：只描述公开算术规则，不复制 IP 内部流水线 =====
  // 下列算术配置与随附 XCI 一致；本测试台专用于本案例的接口配置。
  localparam integer A_W = 24;
  localparam integer B_W = 8;
  localparam integer OUT_W = 32;
  localparam bit USE_ROUNDING = 1'b1; // 1: Random_Rounding；0: Truncate/全精度。
  localparam integer FULL_W = A_W+B_W+1; // PG104 定义的完整复数乘积分量位宽。
  localparam integer DROP = FULL_W-OUT_W; // 缩短输出精度时丢弃的低位数。
  localparam integer CALC_W = FULL_W+1; // 在完整精度之外再留一位，容纳舍入偏置。

  // 使用可参数化的有符号向量，不使用 real 或仅 64 位的 longint。
  // 例如 63×48 位配置的中间量可超过 64 位，不能先在窄类型中运算再扩展。
  typedef logic signed [CALC_W-1:0] calc_t;
  typedef logic signed [OUT_W-1:0] result_t;

  // 量化规则来自 PG104 的 Output Product Range、Rounding 两节：
  // https://docs.amd.com/r/en-US/pg104-cmpy/Output-Product-Range
  // https://docs.amd.com/r/en-US/pg104-cmpy/Rounding
  // DROP=0：完整精度，无量化；Truncate：直接删除低 DROP 位。
  // Random_Rounding：先加 2^(DROP-1)-1+ROUND_CY，再删除低 DROP 位。
  // ROUND_CY 控制恰好半单位时的取舍；模型使用实际接收的 CTRL bit0，
  // 不自行生成随机数。静态 ROUND_CY 也是 PG104 允许的用法。
  function automatic result_t quantize_product(input calc_t product, input logic round_cy);
    calc_t bias, adjusted, shifted;
    begin
      bias = '0;
      if (USE_ROUNDING && DROP>0) begin
        // 先把常量 1 扩展到 CALC_W，避免 32 位常量移位造成溢出。
        bias = (calc_t'(1) <<< (DROP-1)) - calc_t'(1);
        if (round_cy) bias = bias + calc_t'(1);
      end
      adjusted = product + bias;
      // adjusted 明确为 signed，>>> 保留符号；负数去低位相当于向下取整。
      // 不能直接以整数除法代替，因为负数整数除法通常向零截断。
      shifted = adjusted >>> DROP;
      // 返回实际输出的 OUT_W 位二补码字段，不包含 AXI 字节填充位。
      quantize_product = result_t'(shifted);
    end
  endfunction

  task automatic reference_multiply(
    input calc_t a_re, a_im, b_re, b_im,
    input logic round_cy,
    output calc_t full_re, full_im,
    output result_t result_re, result_im
  );
    calc_t rr, ii, ri, ir;
    begin
      // 输入已在接收时符号扩展至 CALC_W；四个乘积都在这个宽度中计算。
      // 两个输入分量的乘积需要 A_W+B_W 位，加减再留一位即可得到 FULL_W。
      rr = a_re*b_re;
      ii = a_im*b_im;
      ri = a_re*b_im;
      ir = a_im*b_re;
      // (a_re+j*a_im)*(b_re+j*b_im)，其中 j*j=-1。
      full_re = rr-ii;
      full_im = ri+ir;
      result_re = quantize_product(full_re, round_cy);
      result_im = quantize_product(full_im, round_cy);
    end
  endtask
  // ===== 参考模型算术定义结束 =====

  calc_t model_full_re, model_full_im;
  result_t expected_re, expected_im; 

  wire [7:0] ctrl_data=8'd0; // 同一 CTRL 数据同时送入 IP，并在接收时供参考模型采样。
  always #5 clk=~clk; // 时钟周期为 10ns。
  complex_multiplier_0 dut (
    .aclk(clk), // IP 时钟。
    .aresetn(rstn), // 低有效同步复位。
    .aclken(1'b1), // 所有周期保持使能。
    .s_axis_a_tvalid(av), // 通道输入有效信号。
    .s_axis_a_tdata(a), // 字节对齐后的有符号复数。
    .s_axis_a_tlast(1'b1), // 本次事务帧结束标记。
    .s_axis_a_tuser(15'd0), // 用户标记固定为零。
    .s_axis_b_tvalid(bv), // 通道输入有效信号。
    .s_axis_b_tdata(b), // 字节对齐后的有符号复数。
    .s_axis_b_tlast(1'b0), // 本次事务帧结束标记。
    .s_axis_ctrl_tvalid(cv), // 通道输入有效信号。
    .s_axis_ctrl_tdata(ctrl_data), // bit0 为 ROUND_CY，其余位为零。
    .s_axis_ctrl_tuser(3'd0), // 用户标记固定为零。
    .m_axis_dout_tvalid(ov), // 输出有效信号。
    .m_axis_dout_tdata(y), // 输出复数总线。
    .m_axis_dout_tlast(out_last), // 输出帧结束标记。
    .m_axis_dout_tuser() // 用户标记输出不参与数值比较。
  );
  // 本案例只有一次 NonBlocking 运算，按顺序完成发送、建模和比较。
  initial begin
    // 同步复位保持 50 周期；释放后再等待 20 周期。
    repeat(50) @(negedge clk);
    rstn=1;
    repeat(20) @(negedge clk);

    // 在下降沿放好数据，三个 TVALID 同时有效一个完整周期。
    a=48'h000001000001; // A=1+j1。
    b=16'h0402;        // B=2+j4。
    av=1; bv=1; cv=1;
    @(posedge clk);    // IP 在此上升沿接收输入，模型读取同一组数据。
    reference_multiply($signed(a[23:0]), $signed(a[47:24]),
                       $signed(b[7:0]), $signed(b[15:8]), ctrl_data[0],
                       model_full_re, model_full_im, expected_re, expected_im);
    // 预期值由输入计算并保存；随后清零输入总线不会改变这次预期。
    $display("CMPY_REFERENCE_INPUT ar=%0d ai=%0d br=%0d bi=%0d",
             $signed(a[23:0]), $signed(a[47:24]), $signed(b[7:0]), $signed(b[15:8]));
    $display("CMPY_REFERENCE_PRODUCT full_re=%0d full_im=%0d drop=%0d rounding=%0d round_cy=%0d",
             model_full_re, model_full_im, DROP, USE_ROUNDING, ctrl_data[0]);
    $display("CMPY_REFERENCE_EXPECTED re=%0d im=%0d", expected_re, expected_im);

    @(negedge clk);
    av=0; bv=0; cv=0; // 撤销有效信号，不再提交新运算。
    a='0; b='0;       // 后续无效周期保持零输入。

    // 不按固定延迟读取，等 IP 自己给出输出有效信号。
    // 在上升沿采样 TVALID 和对应数据，与实际接收方的采样时机一致。
    @(posedge clk);
    while (ov !== 1'b1) @(posedge clk);
    actual_re=$signed(y[31:0]);  // 低 32 位为有符号实部。
    actual_im=$signed(y[63:32]); // 高 32 位为有符号虚部。
    mismatch=(actual_re !== expected_re || actual_im !== expected_im);
    $display("CMPY_SAMPLE n=1 actual_re=%0d actual_im=%0d expected_re=%0d expected_im=%0d",
             actual_re, actual_im, expected_re, expected_im);
    $display("CMPY_TLAST actual=%0b expected=0", out_last);
    if (out_last !== 1'b0) $fatal(1,"CMPY_TLAST_MISMATCH");

    // 只提交一次输入；继续观察 100 周期，拒绝额外的有效输出。
    repeat(100) begin
      @(posedge clk);
      if (ov !== 1'b0) $fatal(1,"CMPY_UNEXPECTED_OUTPUT");
    end
    $display("CMPY_CASE_RESULT outputs=1 mismatches=%0d", mismatch);
    if (mismatch) $display("CMPY_CASE_DATA_MISMATCH");
    else $display("CMPY_CASE_PASS");
    $finish;
  end

  // 独立的超时保护：若 IP 一直不给出有效输出，结束仿真而非无限等待。
  initial begin
    #100000;
    $fatal(1,"CMPY_CASE_TIMEOUT");
  end
endmodule

# 仅显示 IP 端口及模型最终预期值；不显示模型中间量或测试台辅助信号。
# 使用 IP 实例的真实端口名称，包括直接接常量的使能、TLAST、TUSER 等端口。
# 在运行前开始记录，保留完整波形历史。
create_wave_config cmpy_case
set cmpy_wave_count 0
add_wave_divider {Clock and control}
set signal [get_objects /tb_complex_multiplier/dut/aclk]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/aclk"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/aresetn]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/aresetn"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/aclken]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/aclken"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
add_wave_divider {IP input A}
set signal [get_objects /tb_complex_multiplier/dut/s_axis_a_tvalid]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_a_tvalid"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_a_tdata]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_a_tdata"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_a_tlast]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_a_tlast"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_a_tuser]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_a_tuser"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
add_wave_divider {IP input B}
set signal [get_objects /tb_complex_multiplier/dut/s_axis_b_tvalid]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_b_tvalid"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_b_tdata]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_b_tdata"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_b_tlast]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_b_tlast"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
add_wave_divider {IP input CTRL}
set signal [get_objects /tb_complex_multiplier/dut/s_axis_ctrl_tvalid]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_ctrl_tvalid"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_ctrl_tdata]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_ctrl_tdata"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/s_axis_ctrl_tuser]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/s_axis_ctrl_tuser"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
add_wave_divider {IP output}
set signal [get_objects /tb_complex_multiplier/dut/m_axis_dout_tvalid]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/m_axis_dout_tvalid"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/m_axis_dout_tdata]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/m_axis_dout_tdata"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/m_axis_dout_tlast]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/m_axis_dout_tlast"}
log_wave $signal
add_wave -radix bin $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/dut/m_axis_dout_tuser]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/dut/m_axis_dout_tuser"}
log_wave $signal
add_wave -radix hex $signal
incr cmpy_wave_count
add_wave_divider {Expected result - signed decimal}
set signal [get_objects /tb_complex_multiplier/expected_re]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/expected_re"}
log_wave $signal
add_wave -radix dec $signal
incr cmpy_wave_count
set signal [get_objects /tb_complex_multiplier/expected_im]
if {[llength $signal] != 1} {error "Missing waveform signal: /tb_complex_multiplier/expected_im"}
log_wave $signal
add_wave -radix dec $signal
incr cmpy_wave_count
run all
save_wave_config cmpy_wave.wcfg
puts "CMPY_WAVE_READY signals=$cmpy_wave_count"

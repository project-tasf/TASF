set case_dir [file dirname [file normalize [info script]]]
open_project [file join $case_dir fir_case.xpr]
set_param general.maxThreads 1
source [file join $case_dir configure_ip.tcl]
generate_target simulation [get_ips fir_0]
launch_simulation -simset sim_1 -mode behavioral
close_sim -force
close_project
exit

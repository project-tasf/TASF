create_wave_config fir_case
foreach name {aclk aresetn phase output_number s_axis_data_tdata s_axis_data_tvalid s_axis_data_tready m_axis_data_tdata actual_tdata expected_tdata m_axis_data_tvalid m_axis_data_tuser} {
 set sig [get_objects /tb_fir/$name]
 if {[llength $sig] != 1} {error "Missing waveform signal: $name"}
 log_wave $sig
 add_wave -radix dec $sig
}
run all
save_wave_config fir_wave.wcfg
puts WAVE_READY

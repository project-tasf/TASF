`timescale 1ns/1ps
module tb_fir;
// 1. DUT external interfaces and observation-only reference signals.
reg aclk=0,aresetn=0,s_axis_data_tvalid=0;reg [7:0] s_axis_data_tdata=0;
wire s_axis_data_tready,m_axis_data_tvalid;wire [15:0] m_axis_data_tdata;
wire m_axis_data_tuser;
integer phase=0,received=0,checked=0,mismatch=0,fd,output_number=0,total_bad=0;
longint signed expected_tdata,actual_tdata,stimulus;
always #5 aclk=~aclk;
fir_0 dut(.m_axis_data_tuser(m_axis_data_tuser),.aclk(aclk),.aresetn(aresetn),.s_axis_data_tdata(s_axis_data_tdata),.s_axis_data_tvalid(s_axis_data_tvalid),.s_axis_data_tready(s_axis_data_tready),.m_axis_data_tvalid(m_axis_data_tvalid),.m_axis_data_tdata(m_axis_data_tdata));
// Constant samples fill each channel independently; after startup y=sum(coeff)*sample.
// Model uses the requested signed input and coefficients, never DUT internals.
// 2. Independent steady-state model and output-transaction checks.
always @(posedge aclk) if(aresetn && m_axis_data_tvalid) begin
 received=received+1;output_number=output_number+1;
 actual_tdata=$signed(m_axis_data_tdata[10:0]);expected_tdata=64'sd8*stimulus*(-1);
 if(received>8) begin
  checked=checked+1;
  if(actual_tdata!==expected_tdata)mismatch=mismatch+1;
  $fdisplay(fd,"%0d,%0d,%.3f,%0d,%0d,%0d",phase,output_number,$realtime,stimulus,expected_tdata,actual_tdata);
  if(checked==1)$display("OBSERVE phase=%0d input=%0d expected=%0d actual=%0d",phase,stimulus,expected_tdata,actual_tdata);
 end
end
// 3. Stimulus: reset, constant fill, endpoint test, then adjacent-value control.
task run_phase(input integer id,input longint signed value);
 integer n;begin
 @(negedge aclk);aresetn=0;s_axis_data_tvalid=0;phase=id;stimulus=value;s_axis_data_tdata=value;received=0;checked=0;mismatch=0;
 repeat(32)@(negedge aclk);aresetn=1;repeat(32)@(negedge aclk);
 // VALID and DATA remain stable through input backpressure. Output is always accepted.
 for(n=0;n<32;n=n+1)begin
  @(negedge aclk);s_axis_data_tvalid=1;@(posedge aclk);while(!s_axis_data_tready)@(posedge aclk);
  @(negedge aclk);s_axis_data_tvalid=0;repeat(10)@(negedge aclk);
 end
 repeat(1024)@(negedge aclk);
 $display("RESULT phase=%0d received=%0d checked=%0d mismatch=%0d",phase,received,checked,mismatch);
 if(received!=32 || checked!=24)$fatal(1,"COUNT_ERROR");
 if(id==0 && mismatch!=checked)$fatal(1,"EXPECTED_ENDPOINT_DIFFERENCE_NOT_REPRODUCED");
 if(id==1 && mismatch!=0)$fatal(1,"NORMAL_CONTROL_FAILED");
 total_bad=total_bad+mismatch;
 end endtask
initial begin
 fd=$fopen("output_trace.csv","w");$fdisplay(fd,"phase,output_number,time_ns,input,expected,actual");
 run_phase(0,-64'sd128);run_phase(1,-64'sd127);
 $fclose(fd);$display("FIR_CASE_COMPLETE endpoint_differences=%0d control_pass=1",total_bad);$finish;
end
initial begin #4000000;$fatal(1,"TIMEOUT");end
endmodule

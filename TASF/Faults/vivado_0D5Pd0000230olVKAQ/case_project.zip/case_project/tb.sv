`timescale 1ns/1ps
module tb;
  // IP configuration is saved in mailbox_0.xci. These constants describe only
  // the external clock, reset and traffic used by this standalone simulation.
  localparam real HALF_PERIOD_NS = 5;
  localparam bit RESET_ACTIVE = 1;
  localparam int WORDS0=3, WORDS1=0;
  localparam int INITIAL_STALL=0, READY_PERIOD=1;
  localparam bit LAST_ENABLE=1;
  reg clk=0, SYS_Rst=RESET_ACTIVE;
  always #(HALF_PERIOD_NS) clk=~clk;

  reg [31:0] sd[0:1];
  reg [1:0] sl=0, sv=0, mr=0;
  wire [31:0] md[0:1];
  wire [1:0] sr, ml, mv, irq;
  // Named aliases below are direct connections to IP ports, not calculated
  // substitutes for the IP outputs. All four ACLK ports share the same clock.
  wire [31:0] S0_AXIS_TDATA=sd[0], S1_AXIS_TDATA=sd[1];
  wire S0_AXIS_TLAST=sl[0], S1_AXIS_TLAST=sl[1];
  wire S0_AXIS_TVALID=sv[0], S1_AXIS_TVALID=sv[1];
  wire S0_AXIS_TREADY=sr[0], S1_AXIS_TREADY=sr[1];
  wire [31:0] M0_AXIS_TDATA=md[0], M1_AXIS_TDATA=md[1];
  wire M0_AXIS_TLAST=ml[0], M1_AXIS_TLAST=ml[1];
  wire M0_AXIS_TVALID=mv[0], M1_AXIS_TVALID=mv[1];
  wire M0_AXIS_TREADY=mr[0], M1_AXIS_TREADY=mr[1];
  mailbox_0 dut (
    .SYS_Rst(SYS_Rst),
    .S0_AXIS_ACLK(clk), .M0_AXIS_ACLK(clk),
    .S1_AXIS_ACLK(clk), .M1_AXIS_ACLK(clk),
    .S0_AXIS_TDATA(S0_AXIS_TDATA), .S0_AXIS_TLAST(S0_AXIS_TLAST),
    .S0_AXIS_TVALID(S0_AXIS_TVALID), .S0_AXIS_TREADY(sr[0]),
    .S1_AXIS_TDATA(S1_AXIS_TDATA), .S1_AXIS_TLAST(S1_AXIS_TLAST),
    .S1_AXIS_TVALID(S1_AXIS_TVALID), .S1_AXIS_TREADY(sr[1]),
    .M0_AXIS_TDATA(md[0]), .M0_AXIS_TLAST(ml[0]),
    .M0_AXIS_TVALID(mv[0]), .M0_AXIS_TREADY(M0_AXIS_TREADY),
    .M1_AXIS_TDATA(md[1]), .M1_AXIS_TLAST(ml[1]),
    .M1_AXIS_TVALID(mv[1]), .M1_AXIS_TREADY(M1_AXIS_TREADY),
    .Interrupt_0(irq[0]), .Interrupt_1(irq[1])
  );

  // Independent golden model: two ordered queues. Mailbox routes S0 to M1
  // and S1 to M0. Each queue entry is the DATA/LAST pair accepted at an input
  // rising edge, i.e. TVALID && TREADY. A waiting input is not enqueued twice.
  // The expected result never comes from DUT outputs or internal RTL signals.
  // There is no assumed FIFO latency, memory implementation or output schedule.
  logic [32:0] expected[0:1][0:63];
  int sent[0:1]='{0,0}, received[0:1]='{0,0};
  int data_errors=0, last_errors=0;
  bit input_held[0:1]='{0,0}, output_held[0:1]='{0,0};
  logic [32:0] input_previous[0:1], output_previous[0:1];
  integer trace_file;
  bit receiver_done=0;

  // Queue heads are meaningful when the corresponding output TVALID is 1.
  // Compare immediately before its rising-edge handshake; then the head moves
  // to the following word. Zero during an empty queue is just a display value.
  wire [31:0] expected_M0_TDATA = received[0]<sent[1] ? expected[1][received[0]][31:0] : 0;
  wire expected_M0_TLAST = received[0]<sent[1] ? expected[1][received[0]][32] : 0;
  wire [31:0] expected_M1_TDATA = received[1]<sent[0] ? expected[0][received[1]][31:0] : 0;
  wire expected_M1_TLAST = received[1]<sent[0] ? expected[0][received[1]][32] : 0;

  always @(posedge clk) if(SYS_Rst != RESET_ACTIVE) begin
    for(int p=0;p<2;p++) begin
      // AXI4-Stream payload and VALID must be held throughout backpressure.
      if(input_held[p] && (sv[p]!==1 || {sl[p],sd[p]}!==input_previous[p]))
        $fatal(1,"SOURCE_PROTOCOL_ERROR port=%0d",p);
      if(output_held[p] && (mv[p]!==1 || {ml[p],md[p]}!==output_previous[p]))
        $fatal(1,"OUTPUT_PROTOCOL_ERROR port=%0d",p);
      input_held[p]=(sv[p]===1 && sr[p]===0);
      output_held[p]=(mv[p]===1 && mr[p]===0);
      input_previous[p]={sl[p],sd[p]}; output_previous[p]={ml[p],md[p]};
      if(sv[p]===1) begin
        if($isunknown({sr[p],sl[p],sd[p]})) $fatal(1,"UNKNOWN_INPUT port=%0d",p);
        if(sr[p]===1) begin
          if(sent[p]>=64) $fatal(1,"MODEL_CAPACITY_EXCEEDED");
          expected[p][sent[p]]={sl[p],sd[p]}; sent[p]++;
          $fdisplay(trace_file,"IN,%0.3f,%0d,%0d,%0b",$realtime,p,sd[p],sl[p]);
          $display("INPUT ns=%0.3f S%0d data=%0d last=%0b",$realtime,p,sd[p],sl[p]);
        end
      end
    end
    for(int p=0;p<2;p++) begin
      if($isunknown(mv[p])) $fatal(1,"UNKNOWN_VALID port=%0d",p);
      if(mv[p]===1 && mr[p]===1) begin
        if(received[p]>=sent[1-p]) $fatal(1,"UNEXPECTED_OUTPUT port=%0d",p);
        if($isunknown({ml[p],md[p]})) $fatal(1,"UNKNOWN_OUTPUT port=%0d",p);
        if(md[p]!==expected[1-p][received[p]][31:0]) data_errors++;
        if(ml[p]!==expected[1-p][received[p]][32]) last_errors++;
        $fdisplay(trace_file,"OUT,%0.3f,%0d,%0d,%0b",$realtime,p,md[p],ml[p]);
        $display("OUTPUT ns=%0.3f M%0d data=%0d last=%0b expected_data=%0d expected_last=%0b",
          $realtime,p,md[p],ml[p],expected[1-p][received[p]][31:0],expected[1-p][received[p]][32]);
        received[p]++;
      end
    end
  end

  // Drive on falling edges, away from the DUT and model sampling edges. Each
  // word is held until accepted. Gap adds idle cycles between words.
  task automatic send_packet(input int p, count, base, gap, start_delay);
    repeat(start_delay) @(negedge clk);
    for(int k=0;k<count;k++) begin
      @(negedge clk); sd[p]=base+k; sl[p]=LAST_ENABLE && (k==count-1); sv[p]=1;
      for(int t=0;t<1000;t++) begin @(posedge clk); if(sr[p]===1) break; end
      if(sr[p]!==1) $fatal(1,"INPUT_TIMEOUT port=%0d",p);
      @(negedge clk); sv[p]=0; sl[p]=0;
      repeat(gap) @(negedge clk);
    end
  endtask

  task automatic receive_packets();
    for(int cycle=0;cycle<2000;cycle++) begin
      @(negedge clk);
      if(received[0]==WORDS1 && received[1]==WORDS0) begin
        mr=2'b11; receiver_done=1; return;
      end
      mr=(cycle>=INITIAL_STALL && (cycle-INITIAL_STALL)%READY_PERIOD==0) ? 2'b11 : 2'b00;
    end
    $fatal(1,"OUTPUT_TIMEOUT received_M0=%0d received_M1=%0d",received[0],received[1]);
  endtask

  initial begin
    trace_file=$fopen("transfers.csv","w");
    if(!trace_file) $fatal(1,"CANNOT_OPEN_TRACE");
    sd[0]=0; sd[1]=0;
    // PG114 recommends at least 16 cycles. Assert for 32, then wait another
    // 32 cycles after release, with both source VALID signals remaining low.
    repeat(32) @(negedge clk); SYS_Rst=!RESET_ACTIVE;
    repeat(32) @(negedge clk);
    fork
      send_packet(0,WORDS0,10,0,0);
      send_packet(1,WORDS1,40,0,0);
      receive_packets();
    join
    // Keep receivers ready to catch any duplicate or late extra output.
    repeat(32) @(negedge clk);
    if(!receiver_done || sent[0]!=WORDS0 || sent[1]!=WORDS1) $fatal(1,"COUNT_ERROR");
    $display("MAILBOX_FINAL sent_S0=%0d sent_S1=%0d received_M0=%0d received_M1=%0d data_errors=%0d last_errors=%0d",
      sent[0],sent[1],received[0],received[1],data_errors,last_errors);
    $fclose(trace_file); $finish;
  end
  initial begin #1000000; $fatal(1,"WATCHDOG_TIMEOUT"); end
endmodule

# Display connected DUT signals and the model queue head.
if {[current_wave_config] eq ""} {create_wave_config}
add_wave /tb/clk
add_wave /tb/SYS_Rst
add_wave /tb/S0_AXIS_TVALID
add_wave /tb/S0_AXIS_TREADY
add_wave -radix unsigned /tb/S0_AXIS_TDATA
add_wave /tb/S0_AXIS_TLAST
add_wave /tb/M1_AXIS_TVALID
add_wave /tb/M1_AXIS_TREADY
add_wave -radix unsigned /tb/M1_AXIS_TDATA
add_wave /tb/M1_AXIS_TLAST
add_wave -radix unsigned /tb/expected_M1_TDATA
add_wave /tb/expected_M1_TLAST
log_wave /tb/*
run all

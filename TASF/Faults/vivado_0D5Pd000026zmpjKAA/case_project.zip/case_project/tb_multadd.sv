`timescale 1ns/1ps
// Independent arithmetic reference: only public input pins feed the model.
module tb_multadd;
  localparam int AW=27, BW=35, CW=19;
  localparam bit A_UNSIGNED=0, B_UNSIGNED=0, C_UNSIGNED=0;
  localparam int OUT_HIGH=62, OUT_LOW=2;
  logic [AW-1:0] A='0;
  logic [BW-1:0] B='0;
  logic [CW-1:0] C='0;
  logic SUBTRACT=0;
  wire [OUT_HIGH-OUT_LOW:0] P;
  logic [OUT_HIGH-OUT_LOW:0] expected_value;
  
  multiply_adder_0 dut(.A(A), .B(B), .C(C), .SUBTRACT(SUBTRACT), .P(P), .PCOUT());

  // 128 bits cover the supported 53-bit operands and the full add/sub result.
  // Extend each pin using its configured signedness BEFORE doing arithmetic.
  // PG192 defines subtraction as C - A*B, not A*B - C.
  function automatic logic [OUT_HIGH-OUT_LOW:0] golden_model(
      input logic [AW-1:0] av, input logic [BW-1:0] bv,
      input logic [CW-1:0] cv, input logic subtract);
    logic signed [127:0] ax, bx, cx, product, total;
    begin
      ax=A_UNSIGNED ? $signed({1'b0,av}) : $signed(av);
      bx=B_UNSIGNED ? $signed({1'b0,bv}) : $signed(bv);
      cx=C_UNSIGNED ? $signed({1'b0,cv}) : $signed(cv);
      product=ax*bx;
      total=subtract ? cx-product : cx+product;
      // Select exactly the output bit slice requested in the saved XCI.
      golden_model=total[OUT_HIGH:OUT_LOW];
    end
  endfunction
  always_comb expected_value=golden_model(A,B,C,SUBTRACT);

  integer fd;
  initial begin
    $timeformat(-9,3," ns",12);
    #200;
    // One calculation, held stable until the combinational/pipelined output settles.
    A=-6; B=4; C=4; SUBTRACT=0;
    #100;
    // This model checks a steady result, not cycle-by-cycle pipeline latency.
    // No golden-model signal drives the DUT. No internal DUT state is read.
    fd=$fopen("result.csv","w");
    $fdisplay(fd,"time_ns,a_hex,b_hex,c_hex,subtract,expected_hex,actual_hex");
    $fdisplay(fd,"%0.3f,%h,%h,%h,%b,%h,%h",$realtime,A,B,C,SUBTRACT,expected_value,P);
    $fclose(fd);
    $display("MULTADD_RESULT time=%t expected=%h actual=%h mismatch=%0d",$realtime,expected_value,P,P!==expected_value);
    $display("MULTADD_CASE_COMPLETE checks=1 mismatches=%0d",P!==expected_value);
    #20; $finish;
  end
  // A timeout is a harness error and cannot be mistaken for a completed comparison.
  initial begin #10000; $fatal(1,"Simulation did not complete"); end
endmodule

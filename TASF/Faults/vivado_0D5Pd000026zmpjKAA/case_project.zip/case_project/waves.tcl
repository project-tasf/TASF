if {[llength [get_wave_configs]] == 0} {create_wave_config}
add_wave -radix hex /tb_multadd/A /tb_multadd/B /tb_multadd/C /tb_multadd/SUBTRACT /tb_multadd/P /tb_multadd/expected_value
run all
save_wave_config waves.wcfg
